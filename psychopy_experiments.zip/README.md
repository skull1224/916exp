# PsychoPy 실험 3종 — 구 경계 효과 · 용량–반응 · ERP

첨부된 `PsychoPy_실험N_조건파일.xlsx` 와 발표 PPT(실험 1·2·3)를 바탕으로 만든 실험 패키지.
실험마다 **Builder(.psyexp) · Coder(.py) · PsychoJS(html/)** 세 가지 형태가 들어 있다.

| 폴더 | 실험 | 패러다임 | 조건 | 리스트 |
|---|---|---|---|---|
| `exp1_boundary_spr/` | 실험 1 구 경계 효과 | 자기조절 읽기(비누적 이동창) | A(0 EU) / B(1 EU) | 2 |
| `exp2_dose_response_spr/` | 실험 2 통합 부하 용량–반응 | 자기조절 읽기(비누적 이동창) | A / B / C (0/1/2 EU) | 3 |
| `exp3_erp_rsvp/` | 실험 3 통합 비용 ERP | 어절 단위 RSVP + 병렬 포트 트리거 | A / B / C | 3 |

## 폴더 구성 (실험마다 동일)

```
expN_xxx/
  expN_xxx.psyexp          Builder 파일 — PsychoPy Builder 에서 열어 실행·수정
  expN_xxx.py              Builder 가 컴파일한 Python 스크립트 (Coder 에서 그대로 실행 가능)
  expN_xxx_coder.py        직접 작성한 간결한 Coder 스크립트 (같은 절차, 읽기 쉬움)
  html/                    PsychoJS 온라인 버전 — index.html, expN_xxx.js, resources/
  conditions/
    practice.xlsx          연습 8문장
    expN_listK.xlsx        목표 24문장 + 필러 48문장 = 72행 (리스트 K)
```

공용 파일
```
stimuli/expN_targets.xlsx   첨부해 주신 원본 조건파일 그대로 (수정 원본)
stimuli/fillers.xlsx        필러 48문장 (질문 12개 = 25%)
stimuli/practice.xlsx       연습 8문장
tools/make_conditions.py    원본 + 필러 + 연습 → conditions/ 생성
tools/build_experiments.py  .psyexp 생성 후 .py / .js 컴파일 (PsychoPy 2025.1.1 API 사용)
```

## 실행 방법

**Builder** — `expN_xxx.psyexp` 를 PsychoPy Builder 에서 열고 ▶ 실행.
대화상자에서 `participant`, `list`(1~2 또는 1~3), `session` 입력. 리스트 번호에 따라
`conditions/expN_list{list}.xlsx` 가 자동으로 선택된다 (코드 컴포넌트의 `condFile`).

**Coder** — `expN_xxx_coder.py` 를 Coder 에서 열고 실행하거나
```bash
"C:\Program Files\PsychoPy\python.exe" exp1_boundary_spr\exp1_boundary_spr_coder.py
```
(`expN_xxx.py` 는 Builder 가 만든 스크립트로, 역시 그대로 실행된다.)

**PsychoJS(온라인)** — Builder 에서 psyexp 를 열고 Pavlovia 에 Sync 하면 `html/` 폴더가
올라간다. `html/resources/conditions/` 에 조건 파일이 이미 복사되어 있다.
`html/` 는 Pavlovia 용이라 로컬에서 바로 열면 PsychoJS 라이브러리(`lib/`)가 없어 실행되지 않는다.

## 절차 (PPT 의 절차도 그대로)

* 실험 1·2 (SPR): 응시점 500 ms → 어절 1…N (스페이스로 진행, 열린 어절 외에는 `―――` 로 가림,
  앞 어절은 다시 가려짐) → 이해 점검 질문(25% 시행, 참 = **F**, 거짓 = **J**) → 공백 800 ms
* 실험 3 (RSVP): 응시점 500 ms → 어절마다 350 ms 제시 + 150 ms 공백 → 질문(25%) → 공백 1000–1400 ms 무선
* 공통: 지시문 → 연습 8시행 → 본실험 72시행(무선, 36번째 시행 앞에서 휴식 1회) → 종료
* ESC 로 언제든 중단 (중단 시점까지의 데이터는 저장됨)

## 데이터 열 (data/ 폴더, *.csv)

조건 파일의 모든 열(itemID, cond, EU, trialType, sentence, w1–w8, nRegion, critRegion, qFlag …)이
행마다 같이 저장되고, 여기에 다음이 추가된다.

| 열 | 내용 |
|---|---|
| `rt_w1` … `rt_w8` | (실험 1·2) 어절별 읽기 시간 ms. 어절 i 가 열린 뒤 다음 스페이스까지. 어절이 없는 칸은 빈칸 |
| `rt_total`, `nWordsRead` | 문장 전체 읽기 시간, 읽은 어절 수 |
| `sprKey.keys / sprKey.rt` | (Builder 버전) 스페이스 누름 원자료 |
| `onset_w1` … `onset_w8` | (실험 3 Coder) 각 어절이 실제로 화면에 그려진 시각 ms — 타이밍 QA 용 |
| `qResp.keys / qResp.corr / qResp.rt` (Builder), `qResp / qAcc / qRT` (Coder) | 이해 점검 반응·정오·RT |
| `itiDur` | (실험 3 Coder) 실제 사용된 ITI |

분석 구간은 조건파일 열 그대로: 임계 어절 = `critRegion`(5), spillover = 6·7, 점검 구간 = 4·3.
필러는 `trialType == 'filler'` 로 제외한다.

## 실험 3 트리거

| 트리거 | 값 |
|---|---|
| 문장 시작(응시점 개시) `trigStart` | A 10 / B 20 / C 30 / 필러 90 / 연습 80 |
| 어절 개시 `trig1`–`trigN` | 조건코드×10 + 어절 번호 → **임계 어절 = 15 / 25 / 35** (필러 91–98, 연습 81–88) |
| 질문 제시 `trigQ` | 200 |
| 반응 | 201(참 F) / 202(거짓 J) |

* 트리거는 `win.callOnFlip` 으로 **어절이 실제로 그려지는 flip 에 맞춰** 보내고, 다음 프레임(≈16 ms)에 0 으로 리셋한다.
  반응 트리거는 10 ms 펄스.
* 대화상자 `triggers` 에 `y` 를 넣으면 `port` 주소(16진수, 예 `0x0378`, `0xD010`)로 병렬 포트를 연다.
  `n` 이면 포트 없이 실행하고 로그(`*.log`)에 `TRIGGER n` 만 남긴다 → EEG 없이 행동 파일럿 가능.
* 병렬 포트는 `inpoutx64.dll` 이 필요하다 (Standalone PsychoPy 에 포함). USB-병렬 어댑터는 보통 동작하지 않는다.
* PsychoJS(온라인) 버전은 브라우저에서 포트에 접근할 수 없으므로 트리거 없이 행동 데이터만 모은다.

## 직접 확인·수정해야 할 것

1. **필러·연습 문장** — `tools/make_conditions.py` 안의 `FILLERS`(48개) / `PRACTICE`(8개)는 실험이 바로 돌아가도록
   제가 작성한 초안이다. 문장 자연성, 구조 분산(관형절 과다 노출 방지), 질문 25% 비율을 검토한 뒤
   필요하면 고치고 `python tools/make_conditions.py` 를 다시 실행하면 conditions/ 가 갱신된다.
   (필러는 6~8어절이라 `w8`, `trig8` 열이 추가되어 있다. 목표 문항은 w8 이 비어 있다.)
2. **글꼴** — `Malgun Gothic`(Windows 기본). macOS 에서 돌리면 `AppleGothic` 등으로 바꾼다.
3. **표본 수** — 원본 README 의 경고대로 실험 2 는 48세트, 실험 3 은 120세트(조건당 40시행 이상)로
   자극을 늘려야 한다. `stimuli/expN_targets.xlsx` 의 시트에 행을 추가한 뒤 1번 스크립트를 재실행하면 된다.
4. **연속 목표 문항 제한** — 루프는 완전 무선(`random`)이라 목표 문항이 연달아 나올 수 있다.
   제약이 필요하면 조건 파일에 미리 순서를 정해 두고 루프 순서를 `sequential` 로 바꾼다.
5. **실험 3 타이밍 검증** — 실제 EEG 장비에서 포토다이오드로 어절 개시와 트리거의 지연을 한 번 측정해 둔다.
   Coder 버전의 `onset_w1..8` 열과 로그의 `TRIGGER` 시각으로 소프트웨어 쪽 지연은 확인할 수 있다.

## 다시 만들기

```bash
python tools/make_conditions.py
"C:\Program Files\PsychoPy\python.exe" tools/build_experiments.py
```
두 번째 명령은 `.psyexp` 를 새로 쓰고 `.py`, `html/*.js`, `html/index.html`, `html/resources/` 를 다시 생성한다
(Builder 에서 psyexp 를 직접 수정했다면 이 명령을 다시 돌리지 말 것 — 덮어써진다).
