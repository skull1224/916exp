# -*- coding: utf-8 -*-
"""
실험 1 · 구 경계 효과 — 어절 단위 자기조절 읽기 (비누적 이동창)   [Coder 버전]
=============================================================================
Builder 로 만든 exp1_boundary_spr.psyexp 와 같은 절차를 직접 코딩한 스크립트.

절차 (시행마다)
  응시점 500 ms → 어절 1 … 어절 N (스페이스로 진행, 앞 어절은 다시 가려짐)
  → 이해 점검 질문 (qFlag==1 인 시행만, 참=F / 거짓=J) → 공백 800 ms

조건 파일
  conditions/practice.xlsx          연습 8문장
  conditions/exp1_list{K}.xlsx      목표 24 + 필러 48 (K = 대화상자의 list)

측정치
  rt_w1 … rt_w8 : 어절별 읽기 시간(ms). 어절 i 가 열린 뒤 다음 스페이스까지.
  rt_total, nWordsRead, qResp, qRT, qAcc

실행:  Standalone PsychoPy 의 Coder 에서 열어 Run, 또는
       "C:\\Program Files\\PsychoPy\\python.exe" exp1_boundary_spr_coder.py
"""
import os

from psychopy import core, data, gui, logging, visual
from psychopy.hardware import keyboard

# ----------------------------------------------------------------------------
# 설정
# ----------------------------------------------------------------------------
EXP_NAME = 'exp1_boundary_spr'
N_LISTS = 2
FONT = 'Malgun Gothic'
MASK = '\u2015'            # '―'  어절을 가리는 기호 (음절 수만큼 반복)
FIX_DUR = 0.5              # 응시점
BLANK_DUR = 0.8            # 시행 간 공백
BREAK_AT = 36              # 본실험 36번째 시행 직전에 휴식
ADVANCE_KEY = 'space'
ANS_KEYS = ['f', 'j']      # f = 참, j = 거짓
FULLSCREEN = True

INSTR = (
    "어절 단위 자기조절 읽기 과제\n\n"
    "화면에 문장이 '―――' 로 가려져 나옵니다.\n"
    "스페이스 바를 누를 때마다 어절이 하나씩 열리고, 앞 어절은 다시 가려집니다.\n\n"
    "자연스러운 속도로, 내용을 이해하면서 읽어 주세요.\n"
    "일부 문장 뒤에는 내용을 묻는 질문이 나옵니다.\n\n"
    "참(맞다) = F 키          거짓(틀리다) = J 키\n\n"
    "먼저 연습을 합니다. 준비되면 스페이스 바를 누르세요."
)
PRAC_END = ("연습이 끝났습니다.\n\n본 실험은 총 72개 문장이며, 중간에 한 번 쉬는 시간이 있습니다.\n\n"
            "준비되면 스페이스 바를 눌러 시작하세요.")
BREAK_TXT = "잠시 쉬어 가세요.\n\n계속하려면 스페이스 바를 누르세요."
END_TXT = "실험이 끝났습니다.\n\n참여해 주셔서 감사합니다."
Q_HINT = "참 = F                    거짓 = J"

_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# ----------------------------------------------------------------------------
# 참가자 정보
# ----------------------------------------------------------------------------
expInfo = {'participant': '', 'list': '1', 'session': '001'}
dlg = gui.DlgFromDict(expInfo, title=EXP_NAME, order=['participant', 'list', 'session'])
if not dlg.OK:
    core.quit()
expInfo['date'] = data.getDateStr()
expInfo['expName'] = EXP_NAME
listNo = int(expInfo['list'])
assert 1 <= listNo <= N_LISTS, 'list 는 1~%d' % N_LISTS

dataDir = os.path.join(_thisDir, 'data')
os.makedirs(dataDir, exist_ok=True)
filename = os.path.join(dataDir, '%s_%s_%s' % (expInfo['participant'], EXP_NAME, expInfo['date']))
thisExp = data.ExperimentHandler(name=EXP_NAME, extraInfo=expInfo, dataFileName=filename,
                                 savePickle=True, saveWideText=True)
logFile = logging.LogFile(filename + '.log', level=logging.DATA)
logging.console.setLevel(logging.WARNING)

# ----------------------------------------------------------------------------
# 창·자극·장치
# ----------------------------------------------------------------------------
win = visual.Window(fullscr=FULLSCREEN, size=(1280, 720), color='black', units='height',
                    allowGUI=False)
win.mouseVisible = False
frameDur = win.monitorFramePeriod or (1.0 / 60)

kb = keyboard.Keyboard()
msgStim = visual.TextStim(win, text='', font=FONT, height=0.04, wrapWidth=1.7, color='white')
fixStim = visual.TextStim(win, text='+', font=FONT, height=0.08, color='white')
sprStim = visual.TextStim(win, text='', font=FONT, height=0.055, wrapWidth=1.8, color='white')
qStim = visual.TextStim(win, text='', font=FONT, height=0.06, wrapWidth=1.7, pos=(0, 0.1), color='white')
qHint = visual.TextStim(win, text=Q_HINT, font=FONT, height=0.04, pos=(0, -0.2), color='lightgray')


def check_escape():
    if kb.getKeys(['escape'], waitRelease=False):
        thisExp.saveAsWideText(filename + '.csv')
        thisExp.saveAsPickle(filename)
        win.close()
        core.quit()


def show_message(text, keys=(ADVANCE_KEY,)):
    msgStim.text = text
    msgStim.draw()
    win.flip()
    kb.clearEvents()
    while True:
        check_escape()
        if kb.getKeys(list(keys), waitRelease=False):
            break
        msgStim.draw()
        win.flip()


def show_for(stim, seconds):
    """stim(None 이면 빈 화면)을 정확히 seconds 동안 flip 단위로 보여준다."""
    clock = core.Clock()
    while win.getFutureFlipTime(clock=clock) < seconds - frameDur * 0.5:
        check_escape()
        if stim is not None:
            stim.draw()
        win.flip()


# ----------------------------------------------------------------------------
# 시행
# ----------------------------------------------------------------------------
def self_paced_reading(sentence):
    """비누적 이동창. 어절별 읽기 시간(s) 리스트를 돌려준다."""
    words = sentence.split(' ')
    masks = [MASK * len(w) for w in words]
    nWords = len(words)

    def display(idx):
        disp = list(masks)
        if idx >= 0:
            disp[idx] = words[idx]
        sprStim.text = ' '.join(disp)

    display(-1)                       # 전부 가린 상태
    sprStim.draw()
    win.callOnFlip(kb.clock.reset)    # 키 rt 의 기준점 = 이 flip
    win.callOnFlip(kb.clearEvents, eventType='keyboard')
    win.flip()

    rts = []
    lastRT = None
    idx = -1
    while True:
        check_escape()
        keys = kb.getKeys([ADVANCE_KEY], waitRelease=False)
        for k in keys:
            if idx >= 0:
                rts.append(k.rt - lastRT)   # 어절 idx 의 읽기 시간
            lastRT = k.rt
            idx += 1
            if idx >= nWords:
                return rts
            display(idx)
        sprStim.draw()
        win.flip()


def comprehension_question(question, corrKey):
    qStim.text = question
    qStim.draw()
    qHint.draw()
    win.callOnFlip(kb.clock.reset)
    win.callOnFlip(kb.clearEvents, eventType='keyboard')
    win.flip()
    while True:
        check_escape()
        keys = kb.getKeys(ANS_KEYS, waitRelease=False)
        if keys:
            k = keys[0]
            return k.name, k.rt, int(k.name == str(corrKey))
        qStim.draw()
        qHint.draw()
        win.flip()


def run_trial(trial):
    show_for(fixStim, FIX_DUR)
    rts = self_paced_reading(trial['sentence'])
    for i in range(8):
        thisExp.addData('rt_w%d' % (i + 1), round(rts[i] * 1000, 1) if i < len(rts) else '')
    thisExp.addData('rt_total', round(sum(rts) * 1000, 1))
    thisExp.addData('nWordsRead', len(rts))

    if int(trial.get('qFlag') or 0) == 1:
        resp, rt, acc = comprehension_question(trial['question'], trial['corrKey'])
        thisExp.addData('qResp', resp)
        thisExp.addData('qRT', round(rt * 1000, 1))
        thisExp.addData('qAcc', acc)
    show_for(None, BLANK_DUR)


def run_block(condFile, name, break_at=None):
    trials = data.TrialHandler(trialList=data.importConditions(condFile), nReps=1,
                               method='random', name=name, extraInfo=expInfo)
    thisExp.addLoop(trials)
    for trial in trials:
        if break_at is not None and trials.thisN == break_at:
            show_message(BREAK_TXT)
        run_trial(trial)
        thisExp.nextEntry()


# ----------------------------------------------------------------------------
# 실험 흐름
# ----------------------------------------------------------------------------
show_message(INSTR)
run_block('conditions/practice.xlsx', 'practice')
show_message(PRAC_END)
run_block('conditions/exp1_list%d.xlsx' % listNo, 'trials', break_at=BREAK_AT)

msgStim.text = END_TXT
msgStim.draw()
win.flip()
core.wait(3.0)

thisExp.saveAsWideText(filename + '.csv')
thisExp.saveAsPickle(filename)
logging.flush()
win.close()
core.quit()
