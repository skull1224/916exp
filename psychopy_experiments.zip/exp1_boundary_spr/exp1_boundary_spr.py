﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2025.1.1),
    on September 16, 2026, at 20:52
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2025.1.1'
expName = 'exp1_boundary_spr'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': '',
    'list': '1',
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = (1024, 768)
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\sung\\Desktop\\새 폴더 (3)\\psychopy_experiments\\exp1_boundary_spr\\exp1_boundary_spr.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color='black', colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = 'black'
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    if deviceManager.getDevice('instructionsKey') is None:
        # initialise instructionsKey
        instructionsKey = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='instructionsKey',
        )
    if deviceManager.getDevice('sprKey') is None:
        # initialise sprKey
        sprKey = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='sprKey',
        )
    if deviceManager.getDevice('qResp') is None:
        # initialise qResp
        qResp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='qResp',
        )
    if deviceManager.getDevice('practiceEndKey') is None:
        # initialise practiceEndKey
        practiceEndKey = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='practiceEndKey',
        )
    if deviceManager.getDevice('breakKey') is None:
        # initialise breakKey
        breakKey = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='breakKey',
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "instructions" ---
    instructionsText = visual.TextStim(win=win, name='instructionsText',
        text="어절 단위 자기조절 읽기 과제\n\n화면에 문장이 '―――' 로 가려져 나옵니다.\n스페이스 바를 누를 때마다 어절이 하나씩 열리고, 앞 어절은 다시 가려집니다.\n\n자연스러운 속도로, 내용을 이해하면서 읽어 주세요.\n일부 문장 뒤에는 내용을 묻는 질문이 나옵니다.\n\n참(맞다) = F 키          거짓(틀리다) = J 키\n\n먼저 연습을 합니다. 준비되면 스페이스 바를 누르세요.",
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.04, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    instructionsKey = keyboard.Keyboard(deviceName='instructionsKey')
    
    # --- Initialize components for Routine "fixation" ---
    fixCross = visual.TextStim(win=win, name='fixCross',
        text='+',
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.08, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "spr" ---
    sprStim = visual.TextStim(win=win, name='sprStim',
        text=None,
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.8, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    sprKey = keyboard.Keyboard(deviceName='sprKey')
    # Run 'Begin Experiment' code from sprCode
    # 리스트 번호로 조건 파일을 고른다 (conditions/exp1_list1.xlsx ...)
    condFile = 'conditions/exp1_list' + str(expInfo['list']) + '.xlsx'
    MASK = '―'   # 어절을 가리는 기호 (음절 수만큼 반복)
    
    
    # --- Initialize components for Routine "qCheck" ---
    qText = visual.TextStim(win=win, name='qText',
        text='',
        font='Malgun Gothic',
        pos=(0, 0.1), draggable=False, height=0.06, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    qHint = visual.TextStim(win=win, name='qHint',
        text='참 = F                    거짓 = J',
        font='Malgun Gothic',
        pos=(0, -0.2), draggable=False, height=0.04, wrapWidth=1.7, ori=0.0, 
        color='lightgray', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    qResp = keyboard.Keyboard(deviceName='qResp')
    
    # --- Initialize components for Routine "blank" ---
    blankText = visual.TextStim(win=win, name='blankText',
        text=None,
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "practiceEnd" ---
    practiceEndText = visual.TextStim(win=win, name='practiceEndText',
        text='연습이 끝났습니다.\n\n본 실험은 총 72개 문장이며, 중간에 한 번 쉬는 시간이 있습니다.\n\n준비되면 스페이스 바를 눌러 시작하세요.',
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.04, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    practiceEndKey = keyboard.Keyboard(deviceName='practiceEndKey')
    
    # --- Initialize components for Routine "breakRest" ---
    breakText = visual.TextStim(win=win, name='breakText',
        text='잠시 쉬어 가세요.\n\n계속하려면 스페이스 바를 누르세요.',
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.045, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    breakKey = keyboard.Keyboard(deviceName='breakKey')
    
    # --- Initialize components for Routine "fixation" ---
    fixCross = visual.TextStim(win=win, name='fixCross',
        text='+',
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.08, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "spr" ---
    sprStim = visual.TextStim(win=win, name='sprStim',
        text=None,
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.8, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    sprKey = keyboard.Keyboard(deviceName='sprKey')
    # Run 'Begin Experiment' code from sprCode
    # 리스트 번호로 조건 파일을 고른다 (conditions/exp1_list1.xlsx ...)
    condFile = 'conditions/exp1_list' + str(expInfo['list']) + '.xlsx'
    MASK = '―'   # 어절을 가리는 기호 (음절 수만큼 반복)
    
    
    # --- Initialize components for Routine "qCheck" ---
    qText = visual.TextStim(win=win, name='qText',
        text='',
        font='Malgun Gothic',
        pos=(0, 0.1), draggable=False, height=0.06, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    qHint = visual.TextStim(win=win, name='qHint',
        text='참 = F                    거짓 = J',
        font='Malgun Gothic',
        pos=(0, -0.2), draggable=False, height=0.04, wrapWidth=1.7, ori=0.0, 
        color='lightgray', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    qResp = keyboard.Keyboard(deviceName='qResp')
    
    # --- Initialize components for Routine "blank" ---
    blankText = visual.TextStim(win=win, name='blankText',
        text=None,
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "theEnd" ---
    endText = visual.TextStim(win=win, name='endText',
        text='실험이 끝났습니다.\n\n참여해 주셔서 감사합니다.',
        font='Malgun Gothic',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "instructions" ---
    # create an object to store info about Routine instructions
    instructions = data.Routine(
        name='instructions',
        components=[instructionsText, instructionsKey],
    )
    instructions.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for instructionsKey
    instructionsKey.keys = []
    instructionsKey.rt = []
    _instructionsKey_allKeys = []
    # store start times for instructions
    instructions.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    instructions.tStart = globalClock.getTime(format='float')
    instructions.status = STARTED
    thisExp.addData('instructions.started', instructions.tStart)
    instructions.maxDuration = None
    # keep track of which components have finished
    instructionsComponents = instructions.components
    for thisComponent in instructions.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "instructions" ---
    instructions.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instructionsText* updates
        
        # if instructionsText is starting this frame...
        if instructionsText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instructionsText.frameNStart = frameN  # exact frame index
            instructionsText.tStart = t  # local t and not account for scr refresh
            instructionsText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instructionsText, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instructionsText.started')
            # update status
            instructionsText.status = STARTED
            instructionsText.setAutoDraw(True)
        
        # if instructionsText is active this frame...
        if instructionsText.status == STARTED:
            # update params
            pass
        
        # *instructionsKey* updates
        waitOnFlip = False
        
        # if instructionsKey is starting this frame...
        if instructionsKey.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instructionsKey.frameNStart = frameN  # exact frame index
            instructionsKey.tStart = t  # local t and not account for scr refresh
            instructionsKey.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instructionsKey, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instructionsKey.started')
            # update status
            instructionsKey.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(instructionsKey.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(instructionsKey.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if instructionsKey.status == STARTED and not waitOnFlip:
            theseKeys = instructionsKey.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _instructionsKey_allKeys.extend(theseKeys)
            if len(_instructionsKey_allKeys):
                instructionsKey.keys = _instructionsKey_allKeys[-1].name  # just the last key pressed
                instructionsKey.rt = _instructionsKey_allKeys[-1].rt
                instructionsKey.duration = _instructionsKey_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=instructions,
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            instructions.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in instructions.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "instructions" ---
    for thisComponent in instructions.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for instructions
    instructions.tStop = globalClock.getTime(format='float')
    instructions.tStopRefresh = tThisFlipGlobal
    thisExp.addData('instructions.stopped', instructions.tStop)
    # check responses
    if instructionsKey.keys in ['', [], None]:  # No response was made
        instructionsKey.keys = None
    thisExp.addData('instructionsKey.keys',instructionsKey.keys)
    if instructionsKey.keys != None:  # we had a response
        thisExp.addData('instructionsKey.rt', instructionsKey.rt)
        thisExp.addData('instructionsKey.duration', instructionsKey.duration)
    thisExp.nextEntry()
    # the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    practice = data.TrialHandler2(
        name='practice',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('conditions/practice.xlsx'), 
        seed=None, 
    )
    thisExp.addLoop(practice)  # add the loop to the experiment
    thisPractice = practice.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPractice.rgb)
    if thisPractice != None:
        for paramName in thisPractice:
            globals()[paramName] = thisPractice[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisPractice in practice:
        practice.status = STARTED
        if hasattr(thisPractice, 'status'):
            thisPractice.status = STARTED
        currentLoop = practice
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisPractice.rgb)
        if thisPractice != None:
            for paramName in thisPractice:
                globals()[paramName] = thisPractice[paramName]
        
        # --- Prepare to start Routine "fixation" ---
        # create an object to store info about Routine fixation
        fixation = data.Routine(
            name='fixation',
            components=[fixCross],
        )
        fixation.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for fixation
        fixation.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        fixation.tStart = globalClock.getTime(format='float')
        fixation.status = STARTED
        thisExp.addData('fixation.started', fixation.tStart)
        fixation.maxDuration = None
        # keep track of which components have finished
        fixationComponents = fixation.components
        for thisComponent in fixation.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "fixation" ---
        fixation.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # if trial has changed, end Routine now
            if hasattr(thisPractice, 'status') and thisPractice.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixCross* updates
            
            # if fixCross is starting this frame...
            if fixCross.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixCross.frameNStart = frameN  # exact frame index
                fixCross.tStart = t  # local t and not account for scr refresh
                fixCross.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixCross, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixCross.started')
                # update status
                fixCross.status = STARTED
                fixCross.setAutoDraw(True)
            
            # if fixCross is active this frame...
            if fixCross.status == STARTED:
                # update params
                pass
            
            # if fixCross is stopping this frame...
            if fixCross.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixCross.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fixCross.tStop = t  # not accounting for scr refresh
                    fixCross.tStopRefresh = tThisFlipGlobal  # on global time
                    fixCross.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixCross.stopped')
                    # update status
                    fixCross.status = FINISHED
                    fixCross.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=fixation,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                fixation.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in fixation.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "fixation" ---
        for thisComponent in fixation.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for fixation
        fixation.tStop = globalClock.getTime(format='float')
        fixation.tStopRefresh = tThisFlipGlobal
        thisExp.addData('fixation.stopped', fixation.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if fixation.maxDurationReached:
            routineTimer.addTime(-fixation.maxDuration)
        elif fixation.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        
        # --- Prepare to start Routine "spr" ---
        # create an object to store info about Routine spr
        spr = data.Routine(
            name='spr',
            components=[sprStim, sprKey],
        )
        spr.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # create starting attributes for sprKey
        sprKey.keys = []
        sprKey.rt = []
        _sprKey_allKeys = []
        # Run 'Begin Routine' code from sprCode
        # 문장을 어절로 쪼개고 전부 가린 상태로 시작한다
        words = sentence.split(' ')
        nWords = len(words)
        masks = [MASK * len(w) for w in words]
        wordIdx = -1        # -1 = 아직 열린 어절 없음
        nPressed = 0        # 처리한 스페이스 누름 수
        sprRTs = []         # 어절별 읽기 시간(s): 어절 i 가 열린 뒤 다음 누름까지
        lastRT = 0.0
        sprStim.setText(' '.join(masks))
        
        # store start times for spr
        spr.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        spr.tStart = globalClock.getTime(format='float')
        spr.status = STARTED
        thisExp.addData('spr.started', spr.tStart)
        spr.maxDuration = None
        # keep track of which components have finished
        sprComponents = spr.components
        for thisComponent in spr.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "spr" ---
        spr.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisPractice, 'status') and thisPractice.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *sprStim* updates
            
            # if sprStim is starting this frame...
            if sprStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sprStim.frameNStart = frameN  # exact frame index
                sprStim.tStart = t  # local t and not account for scr refresh
                sprStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(sprStim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'sprStim.started')
                # update status
                sprStim.status = STARTED
                sprStim.setAutoDraw(True)
            
            # if sprStim is active this frame...
            if sprStim.status == STARTED:
                # update params
                pass
            
            # *sprKey* updates
            waitOnFlip = False
            
            # if sprKey is starting this frame...
            if sprKey.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sprKey.frameNStart = frameN  # exact frame index
                sprKey.tStart = t  # local t and not account for scr refresh
                sprKey.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(sprKey, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'sprKey.started')
                # update status
                sprKey.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(sprKey.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(sprKey.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if sprKey.status == STARTED and not waitOnFlip:
                theseKeys = sprKey.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _sprKey_allKeys.extend(theseKeys)
                if len(_sprKey_allKeys):
                    sprKey.keys = [key.name for key in _sprKey_allKeys]  # storing all keys
                    sprKey.rt = [key.rt for key in _sprKey_allKeys]
                    sprKey.duration = [key.duration for key in _sprKey_allKeys]
            # Run 'Each Frame' code from sprCode
            # 새로 들어온 스페이스 누름을 처리한다 (sprKey 는 'all keys' 저장 → rt 리스트 누적)
            while nPressed < len(sprKey.rt):
                thisRT = sprKey.rt[nPressed]
                nPressed += 1
                if wordIdx >= 0:
                    sprRTs.append(thisRT - lastRT)   # 직전 어절의 읽기 시간
                lastRT = thisRT
                wordIdx += 1
                if wordIdx >= nWords:
                    continueRoutine = False           # 마지막 어절까지 읽음
                    break
                disp = list(masks)
                disp[wordIdx] = words[wordIdx]        # 현재 어절만 열고 나머지는 가림
                sprStim.setText(' '.join(disp))
            
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=spr,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                spr.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in spr.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "spr" ---
        for thisComponent in spr.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for spr
        spr.tStop = globalClock.getTime(format='float')
        spr.tStopRefresh = tThisFlipGlobal
        thisExp.addData('spr.stopped', spr.tStop)
        # check responses
        if sprKey.keys in ['', [], None]:  # No response was made
            sprKey.keys = None
        practice.addData('sprKey.keys',sprKey.keys)
        if sprKey.keys != None:  # we had a response
            practice.addData('sprKey.rt', sprKey.rt)
            practice.addData('sprKey.duration', sprKey.duration)
        # Run 'End Routine' code from sprCode
        # 어절별 읽기 시간을 ms 단위로 저장 (rt_w1 ... rt_w8)
        for i in range(8):
            if i < len(sprRTs):
                thisExp.addData('rt_w%d' % (i + 1), round(sprRTs[i] * 1000, 1))
            else:
                thisExp.addData('rt_w%d' % (i + 1), '')
        thisExp.addData('rt_total', round(sum(sprRTs) * 1000, 1))
        thisExp.addData('nWordsRead', len(sprRTs))
        
        # the Routine "spr" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "qCheck" ---
        # create an object to store info about Routine qCheck
        qCheck = data.Routine(
            name='qCheck',
            components=[qText, qHint, qResp],
        )
        qCheck.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from qCode
        # 이해 점검 질문이 없는 시행은 건너뛴다
        if qFlag != 1:
            continueRoutine = False
        
        qText.setText(question)
        # create starting attributes for qResp
        qResp.keys = []
        qResp.rt = []
        _qResp_allKeys = []
        # store start times for qCheck
        qCheck.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        qCheck.tStart = globalClock.getTime(format='float')
        qCheck.status = STARTED
        thisExp.addData('qCheck.started', qCheck.tStart)
        qCheck.maxDuration = None
        # keep track of which components have finished
        qCheckComponents = qCheck.components
        for thisComponent in qCheck.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "qCheck" ---
        qCheck.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisPractice, 'status') and thisPractice.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *qText* updates
            
            # if qText is starting this frame...
            if qText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                qText.frameNStart = frameN  # exact frame index
                qText.tStart = t  # local t and not account for scr refresh
                qText.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(qText, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'qText.started')
                # update status
                qText.status = STARTED
                qText.setAutoDraw(True)
            
            # if qText is active this frame...
            if qText.status == STARTED:
                # update params
                pass
            
            # *qHint* updates
            
            # if qHint is starting this frame...
            if qHint.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                qHint.frameNStart = frameN  # exact frame index
                qHint.tStart = t  # local t and not account for scr refresh
                qHint.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(qHint, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'qHint.started')
                # update status
                qHint.status = STARTED
                qHint.setAutoDraw(True)
            
            # if qHint is active this frame...
            if qHint.status == STARTED:
                # update params
                pass
            
            # *qResp* updates
            waitOnFlip = False
            
            # if qResp is starting this frame...
            if qResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                qResp.frameNStart = frameN  # exact frame index
                qResp.tStart = t  # local t and not account for scr refresh
                qResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(qResp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'qResp.started')
                # update status
                qResp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(qResp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(qResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if qResp.status == STARTED and not waitOnFlip:
                theseKeys = qResp.getKeys(keyList=['f','j'], ignoreKeys=["escape"], waitRelease=False)
                _qResp_allKeys.extend(theseKeys)
                if len(_qResp_allKeys):
                    qResp.keys = _qResp_allKeys[-1].name  # just the last key pressed
                    qResp.rt = _qResp_allKeys[-1].rt
                    qResp.duration = _qResp_allKeys[-1].duration
                    # was this correct?
                    if (qResp.keys == str(corrKey)) or (qResp.keys == corrKey):
                        qResp.corr = 1
                    else:
                        qResp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=qCheck,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                qCheck.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in qCheck.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "qCheck" ---
        for thisComponent in qCheck.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for qCheck
        qCheck.tStop = globalClock.getTime(format='float')
        qCheck.tStopRefresh = tThisFlipGlobal
        thisExp.addData('qCheck.stopped', qCheck.tStop)
        # check responses
        if qResp.keys in ['', [], None]:  # No response was made
            qResp.keys = None
            # was no response the correct answer?!
            if str(corrKey).lower() == 'none':
               qResp.corr = 1;  # correct non-response
            else:
               qResp.corr = 0;  # failed to respond (incorrectly)
        # store data for practice (TrialHandler)
        practice.addData('qResp.keys',qResp.keys)
        practice.addData('qResp.corr', qResp.corr)
        if qResp.keys != None:  # we had a response
            practice.addData('qResp.rt', qResp.rt)
            practice.addData('qResp.duration', qResp.duration)
        # the Routine "qCheck" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[blankText],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.8:
            # if trial has changed, end Routine now
            if hasattr(thisPractice, 'status') and thisPractice.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *blankText* updates
            
            # if blankText is starting this frame...
            if blankText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                blankText.frameNStart = frameN  # exact frame index
                blankText.tStart = t  # local t and not account for scr refresh
                blankText.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(blankText, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'blankText.started')
                # update status
                blankText.status = STARTED
                blankText.setAutoDraw(True)
            
            # if blankText is active this frame...
            if blankText.status == STARTED:
                # update params
                pass
            
            # if blankText is stopping this frame...
            if blankText.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > blankText.tStartRefresh + 0.8-frameTolerance:
                    # keep track of stop time/frame for later
                    blankText.tStop = t  # not accounting for scr refresh
                    blankText.tStopRefresh = tThisFlipGlobal  # on global time
                    blankText.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'blankText.stopped')
                    # update status
                    blankText.status = FINISHED
                    blankText.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                blank.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.800000)
        # mark thisPractice as finished
        if hasattr(thisPractice, 'status'):
            thisPractice.status = FINISHED
        # if awaiting a pause, pause now
        if practice.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            practice.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'practice'
    practice.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "practiceEnd" ---
    # create an object to store info about Routine practiceEnd
    practiceEnd = data.Routine(
        name='practiceEnd',
        components=[practiceEndText, practiceEndKey],
    )
    practiceEnd.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for practiceEndKey
    practiceEndKey.keys = []
    practiceEndKey.rt = []
    _practiceEndKey_allKeys = []
    # store start times for practiceEnd
    practiceEnd.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    practiceEnd.tStart = globalClock.getTime(format='float')
    practiceEnd.status = STARTED
    thisExp.addData('practiceEnd.started', practiceEnd.tStart)
    practiceEnd.maxDuration = None
    # keep track of which components have finished
    practiceEndComponents = practiceEnd.components
    for thisComponent in practiceEnd.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "practiceEnd" ---
    practiceEnd.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *practiceEndText* updates
        
        # if practiceEndText is starting this frame...
        if practiceEndText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            practiceEndText.frameNStart = frameN  # exact frame index
            practiceEndText.tStart = t  # local t and not account for scr refresh
            practiceEndText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(practiceEndText, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'practiceEndText.started')
            # update status
            practiceEndText.status = STARTED
            practiceEndText.setAutoDraw(True)
        
        # if practiceEndText is active this frame...
        if practiceEndText.status == STARTED:
            # update params
            pass
        
        # *practiceEndKey* updates
        waitOnFlip = False
        
        # if practiceEndKey is starting this frame...
        if practiceEndKey.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            practiceEndKey.frameNStart = frameN  # exact frame index
            practiceEndKey.tStart = t  # local t and not account for scr refresh
            practiceEndKey.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(practiceEndKey, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'practiceEndKey.started')
            # update status
            practiceEndKey.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(practiceEndKey.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(practiceEndKey.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if practiceEndKey.status == STARTED and not waitOnFlip:
            theseKeys = practiceEndKey.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _practiceEndKey_allKeys.extend(theseKeys)
            if len(_practiceEndKey_allKeys):
                practiceEndKey.keys = _practiceEndKey_allKeys[-1].name  # just the last key pressed
                practiceEndKey.rt = _practiceEndKey_allKeys[-1].rt
                practiceEndKey.duration = _practiceEndKey_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=practiceEnd,
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            practiceEnd.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in practiceEnd.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "practiceEnd" ---
    for thisComponent in practiceEnd.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for practiceEnd
    practiceEnd.tStop = globalClock.getTime(format='float')
    practiceEnd.tStopRefresh = tThisFlipGlobal
    thisExp.addData('practiceEnd.stopped', practiceEnd.tStop)
    # check responses
    if practiceEndKey.keys in ['', [], None]:  # No response was made
        practiceEndKey.keys = None
    thisExp.addData('practiceEndKey.keys',practiceEndKey.keys)
    if practiceEndKey.keys != None:  # we had a response
        thisExp.addData('practiceEndKey.rt', practiceEndKey.rt)
        thisExp.addData('practiceEndKey.duration', practiceEndKey.duration)
    thisExp.nextEntry()
    # the Routine "practiceEnd" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials = data.TrialHandler2(
        name='trials',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions(condFile), 
        seed=None, 
    )
    thisExp.addLoop(trials)  # add the loop to the experiment
    thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            globals()[paramName] = thisTrial[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial in trials:
        trials.status = STARTED
        if hasattr(thisTrial, 'status'):
            thisTrial.status = STARTED
        currentLoop = trials
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                globals()[paramName] = thisTrial[paramName]
        
        # --- Prepare to start Routine "breakRest" ---
        # create an object to store info about Routine breakRest
        breakRest = data.Routine(
            name='breakRest',
            components=[breakText, breakKey],
        )
        breakRest.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from breakCode
        # 본실험 36번째 시행 직전에만 쉬는 화면을 보여준다
        if trials.thisN != 36:
            continueRoutine = False
        
        # create starting attributes for breakKey
        breakKey.keys = []
        breakKey.rt = []
        _breakKey_allKeys = []
        # store start times for breakRest
        breakRest.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        breakRest.tStart = globalClock.getTime(format='float')
        breakRest.status = STARTED
        thisExp.addData('breakRest.started', breakRest.tStart)
        breakRest.maxDuration = None
        # keep track of which components have finished
        breakRestComponents = breakRest.components
        for thisComponent in breakRest.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "breakRest" ---
        breakRest.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrial, 'status') and thisTrial.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *breakText* updates
            
            # if breakText is starting this frame...
            if breakText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                breakText.frameNStart = frameN  # exact frame index
                breakText.tStart = t  # local t and not account for scr refresh
                breakText.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(breakText, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'breakText.started')
                # update status
                breakText.status = STARTED
                breakText.setAutoDraw(True)
            
            # if breakText is active this frame...
            if breakText.status == STARTED:
                # update params
                pass
            
            # *breakKey* updates
            waitOnFlip = False
            
            # if breakKey is starting this frame...
            if breakKey.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                breakKey.frameNStart = frameN  # exact frame index
                breakKey.tStart = t  # local t and not account for scr refresh
                breakKey.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(breakKey, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'breakKey.started')
                # update status
                breakKey.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(breakKey.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(breakKey.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if breakKey.status == STARTED and not waitOnFlip:
                theseKeys = breakKey.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _breakKey_allKeys.extend(theseKeys)
                if len(_breakKey_allKeys):
                    breakKey.keys = _breakKey_allKeys[-1].name  # just the last key pressed
                    breakKey.rt = _breakKey_allKeys[-1].rt
                    breakKey.duration = _breakKey_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=breakRest,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                breakRest.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in breakRest.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "breakRest" ---
        for thisComponent in breakRest.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for breakRest
        breakRest.tStop = globalClock.getTime(format='float')
        breakRest.tStopRefresh = tThisFlipGlobal
        thisExp.addData('breakRest.stopped', breakRest.tStop)
        # check responses
        if breakKey.keys in ['', [], None]:  # No response was made
            breakKey.keys = None
        trials.addData('breakKey.keys',breakKey.keys)
        if breakKey.keys != None:  # we had a response
            trials.addData('breakKey.rt', breakKey.rt)
            trials.addData('breakKey.duration', breakKey.duration)
        # the Routine "breakRest" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "fixation" ---
        # create an object to store info about Routine fixation
        fixation = data.Routine(
            name='fixation',
            components=[fixCross],
        )
        fixation.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for fixation
        fixation.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        fixation.tStart = globalClock.getTime(format='float')
        fixation.status = STARTED
        thisExp.addData('fixation.started', fixation.tStart)
        fixation.maxDuration = None
        # keep track of which components have finished
        fixationComponents = fixation.components
        for thisComponent in fixation.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "fixation" ---
        fixation.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrial, 'status') and thisTrial.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixCross* updates
            
            # if fixCross is starting this frame...
            if fixCross.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixCross.frameNStart = frameN  # exact frame index
                fixCross.tStart = t  # local t and not account for scr refresh
                fixCross.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixCross, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixCross.started')
                # update status
                fixCross.status = STARTED
                fixCross.setAutoDraw(True)
            
            # if fixCross is active this frame...
            if fixCross.status == STARTED:
                # update params
                pass
            
            # if fixCross is stopping this frame...
            if fixCross.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixCross.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fixCross.tStop = t  # not accounting for scr refresh
                    fixCross.tStopRefresh = tThisFlipGlobal  # on global time
                    fixCross.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixCross.stopped')
                    # update status
                    fixCross.status = FINISHED
                    fixCross.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=fixation,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                fixation.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in fixation.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "fixation" ---
        for thisComponent in fixation.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for fixation
        fixation.tStop = globalClock.getTime(format='float')
        fixation.tStopRefresh = tThisFlipGlobal
        thisExp.addData('fixation.stopped', fixation.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if fixation.maxDurationReached:
            routineTimer.addTime(-fixation.maxDuration)
        elif fixation.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        
        # --- Prepare to start Routine "spr" ---
        # create an object to store info about Routine spr
        spr = data.Routine(
            name='spr',
            components=[sprStim, sprKey],
        )
        spr.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # create starting attributes for sprKey
        sprKey.keys = []
        sprKey.rt = []
        _sprKey_allKeys = []
        # Run 'Begin Routine' code from sprCode
        # 문장을 어절로 쪼개고 전부 가린 상태로 시작한다
        words = sentence.split(' ')
        nWords = len(words)
        masks = [MASK * len(w) for w in words]
        wordIdx = -1        # -1 = 아직 열린 어절 없음
        nPressed = 0        # 처리한 스페이스 누름 수
        sprRTs = []         # 어절별 읽기 시간(s): 어절 i 가 열린 뒤 다음 누름까지
        lastRT = 0.0
        sprStim.setText(' '.join(masks))
        
        # store start times for spr
        spr.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        spr.tStart = globalClock.getTime(format='float')
        spr.status = STARTED
        thisExp.addData('spr.started', spr.tStart)
        spr.maxDuration = None
        # keep track of which components have finished
        sprComponents = spr.components
        for thisComponent in spr.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "spr" ---
        spr.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrial, 'status') and thisTrial.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *sprStim* updates
            
            # if sprStim is starting this frame...
            if sprStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sprStim.frameNStart = frameN  # exact frame index
                sprStim.tStart = t  # local t and not account for scr refresh
                sprStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(sprStim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'sprStim.started')
                # update status
                sprStim.status = STARTED
                sprStim.setAutoDraw(True)
            
            # if sprStim is active this frame...
            if sprStim.status == STARTED:
                # update params
                pass
            
            # *sprKey* updates
            waitOnFlip = False
            
            # if sprKey is starting this frame...
            if sprKey.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sprKey.frameNStart = frameN  # exact frame index
                sprKey.tStart = t  # local t and not account for scr refresh
                sprKey.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(sprKey, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'sprKey.started')
                # update status
                sprKey.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(sprKey.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(sprKey.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if sprKey.status == STARTED and not waitOnFlip:
                theseKeys = sprKey.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _sprKey_allKeys.extend(theseKeys)
                if len(_sprKey_allKeys):
                    sprKey.keys = [key.name for key in _sprKey_allKeys]  # storing all keys
                    sprKey.rt = [key.rt for key in _sprKey_allKeys]
                    sprKey.duration = [key.duration for key in _sprKey_allKeys]
            # Run 'Each Frame' code from sprCode
            # 새로 들어온 스페이스 누름을 처리한다 (sprKey 는 'all keys' 저장 → rt 리스트 누적)
            while nPressed < len(sprKey.rt):
                thisRT = sprKey.rt[nPressed]
                nPressed += 1
                if wordIdx >= 0:
                    sprRTs.append(thisRT - lastRT)   # 직전 어절의 읽기 시간
                lastRT = thisRT
                wordIdx += 1
                if wordIdx >= nWords:
                    continueRoutine = False           # 마지막 어절까지 읽음
                    break
                disp = list(masks)
                disp[wordIdx] = words[wordIdx]        # 현재 어절만 열고 나머지는 가림
                sprStim.setText(' '.join(disp))
            
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=spr,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                spr.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in spr.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "spr" ---
        for thisComponent in spr.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for spr
        spr.tStop = globalClock.getTime(format='float')
        spr.tStopRefresh = tThisFlipGlobal
        thisExp.addData('spr.stopped', spr.tStop)
        # check responses
        if sprKey.keys in ['', [], None]:  # No response was made
            sprKey.keys = None
        trials.addData('sprKey.keys',sprKey.keys)
        if sprKey.keys != None:  # we had a response
            trials.addData('sprKey.rt', sprKey.rt)
            trials.addData('sprKey.duration', sprKey.duration)
        # Run 'End Routine' code from sprCode
        # 어절별 읽기 시간을 ms 단위로 저장 (rt_w1 ... rt_w8)
        for i in range(8):
            if i < len(sprRTs):
                thisExp.addData('rt_w%d' % (i + 1), round(sprRTs[i] * 1000, 1))
            else:
                thisExp.addData('rt_w%d' % (i + 1), '')
        thisExp.addData('rt_total', round(sum(sprRTs) * 1000, 1))
        thisExp.addData('nWordsRead', len(sprRTs))
        
        # the Routine "spr" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "qCheck" ---
        # create an object to store info about Routine qCheck
        qCheck = data.Routine(
            name='qCheck',
            components=[qText, qHint, qResp],
        )
        qCheck.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from qCode
        # 이해 점검 질문이 없는 시행은 건너뛴다
        if qFlag != 1:
            continueRoutine = False
        
        qText.setText(question)
        # create starting attributes for qResp
        qResp.keys = []
        qResp.rt = []
        _qResp_allKeys = []
        # store start times for qCheck
        qCheck.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        qCheck.tStart = globalClock.getTime(format='float')
        qCheck.status = STARTED
        thisExp.addData('qCheck.started', qCheck.tStart)
        qCheck.maxDuration = None
        # keep track of which components have finished
        qCheckComponents = qCheck.components
        for thisComponent in qCheck.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "qCheck" ---
        qCheck.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrial, 'status') and thisTrial.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *qText* updates
            
            # if qText is starting this frame...
            if qText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                qText.frameNStart = frameN  # exact frame index
                qText.tStart = t  # local t and not account for scr refresh
                qText.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(qText, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'qText.started')
                # update status
                qText.status = STARTED
                qText.setAutoDraw(True)
            
            # if qText is active this frame...
            if qText.status == STARTED:
                # update params
                pass
            
            # *qHint* updates
            
            # if qHint is starting this frame...
            if qHint.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                qHint.frameNStart = frameN  # exact frame index
                qHint.tStart = t  # local t and not account for scr refresh
                qHint.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(qHint, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'qHint.started')
                # update status
                qHint.status = STARTED
                qHint.setAutoDraw(True)
            
            # if qHint is active this frame...
            if qHint.status == STARTED:
                # update params
                pass
            
            # *qResp* updates
            waitOnFlip = False
            
            # if qResp is starting this frame...
            if qResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                qResp.frameNStart = frameN  # exact frame index
                qResp.tStart = t  # local t and not account for scr refresh
                qResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(qResp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'qResp.started')
                # update status
                qResp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(qResp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(qResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if qResp.status == STARTED and not waitOnFlip:
                theseKeys = qResp.getKeys(keyList=['f','j'], ignoreKeys=["escape"], waitRelease=False)
                _qResp_allKeys.extend(theseKeys)
                if len(_qResp_allKeys):
                    qResp.keys = _qResp_allKeys[-1].name  # just the last key pressed
                    qResp.rt = _qResp_allKeys[-1].rt
                    qResp.duration = _qResp_allKeys[-1].duration
                    # was this correct?
                    if (qResp.keys == str(corrKey)) or (qResp.keys == corrKey):
                        qResp.corr = 1
                    else:
                        qResp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=qCheck,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                qCheck.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in qCheck.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "qCheck" ---
        for thisComponent in qCheck.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for qCheck
        qCheck.tStop = globalClock.getTime(format='float')
        qCheck.tStopRefresh = tThisFlipGlobal
        thisExp.addData('qCheck.stopped', qCheck.tStop)
        # check responses
        if qResp.keys in ['', [], None]:  # No response was made
            qResp.keys = None
            # was no response the correct answer?!
            if str(corrKey).lower() == 'none':
               qResp.corr = 1;  # correct non-response
            else:
               qResp.corr = 0;  # failed to respond (incorrectly)
        # store data for trials (TrialHandler)
        trials.addData('qResp.keys',qResp.keys)
        trials.addData('qResp.corr', qResp.corr)
        if qResp.keys != None:  # we had a response
            trials.addData('qResp.rt', qResp.rt)
            trials.addData('qResp.duration', qResp.duration)
        # the Routine "qCheck" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "blank" ---
        # create an object to store info about Routine blank
        blank = data.Routine(
            name='blank',
            components=[blankText],
        )
        blank.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for blank
        blank.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        blank.tStart = globalClock.getTime(format='float')
        blank.status = STARTED
        thisExp.addData('blank.started', blank.tStart)
        blank.maxDuration = None
        # keep track of which components have finished
        blankComponents = blank.components
        for thisComponent in blank.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "blank" ---
        blank.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.8:
            # if trial has changed, end Routine now
            if hasattr(thisTrial, 'status') and thisTrial.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *blankText* updates
            
            # if blankText is starting this frame...
            if blankText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                blankText.frameNStart = frameN  # exact frame index
                blankText.tStart = t  # local t and not account for scr refresh
                blankText.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(blankText, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'blankText.started')
                # update status
                blankText.status = STARTED
                blankText.setAutoDraw(True)
            
            # if blankText is active this frame...
            if blankText.status == STARTED:
                # update params
                pass
            
            # if blankText is stopping this frame...
            if blankText.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > blankText.tStartRefresh + 0.8-frameTolerance:
                    # keep track of stop time/frame for later
                    blankText.tStop = t  # not accounting for scr refresh
                    blankText.tStopRefresh = tThisFlipGlobal  # on global time
                    blankText.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'blankText.stopped')
                    # update status
                    blankText.status = FINISHED
                    blankText.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=blank,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                blank.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in blank.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "blank" ---
        for thisComponent in blank.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for blank
        blank.tStop = globalClock.getTime(format='float')
        blank.tStopRefresh = tThisFlipGlobal
        thisExp.addData('blank.stopped', blank.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if blank.maxDurationReached:
            routineTimer.addTime(-blank.maxDuration)
        elif blank.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.800000)
        # mark thisTrial as finished
        if hasattr(thisTrial, 'status'):
            thisTrial.status = FINISHED
        # if awaiting a pause, pause now
        if trials.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trials'
    trials.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "theEnd" ---
    # create an object to store info about Routine theEnd
    theEnd = data.Routine(
        name='theEnd',
        components=[endText],
    )
    theEnd.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # store start times for theEnd
    theEnd.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    theEnd.tStart = globalClock.getTime(format='float')
    theEnd.status = STARTED
    thisExp.addData('theEnd.started', theEnd.tStart)
    theEnd.maxDuration = None
    # keep track of which components have finished
    theEndComponents = theEnd.components
    for thisComponent in theEnd.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "theEnd" ---
    theEnd.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 3.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *endText* updates
        
        # if endText is starting this frame...
        if endText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            endText.frameNStart = frameN  # exact frame index
            endText.tStart = t  # local t and not account for scr refresh
            endText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(endText, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'endText.started')
            # update status
            endText.status = STARTED
            endText.setAutoDraw(True)
        
        # if endText is active this frame...
        if endText.status == STARTED:
            # update params
            pass
        
        # if endText is stopping this frame...
        if endText.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > endText.tStartRefresh + 3.0-frameTolerance:
                # keep track of stop time/frame for later
                endText.tStop = t  # not accounting for scr refresh
                endText.tStopRefresh = tThisFlipGlobal  # on global time
                endText.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'endText.stopped')
                # update status
                endText.status = FINISHED
                endText.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=theEnd,
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            theEnd.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in theEnd.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "theEnd" ---
    for thisComponent in theEnd.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for theEnd
    theEnd.tStop = globalClock.getTime(format='float')
    theEnd.tStopRefresh = tThisFlipGlobal
    thisExp.addData('theEnd.stopped', theEnd.tStop)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if theEnd.maxDurationReached:
        routineTimer.addTime(-theEnd.maxDuration)
    elif theEnd.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-3.000000)
    thisExp.nextEntry()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
