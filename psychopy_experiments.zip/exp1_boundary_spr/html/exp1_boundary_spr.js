﻿/************************** 
 * Exp1_Boundary_Spr *
 **************************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2025.1.1.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'exp1_boundary_spr';  // from the Builder filename that created this script
let expInfo = {
    'participant': '',
    'list': '1',
    'session': '001',
};
let PILOTING = util.getUrlParameters().has('__pilotToken');

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color('black'),
  units: 'height',
  waitBlanking: true,
  backgroundImage: '',
  backgroundFit: 'none',
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); },flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(instructionsRoutineBegin());
flowScheduler.add(instructionsRoutineEachFrame());
flowScheduler.add(instructionsRoutineEnd());
const practiceLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(practiceLoopBegin(practiceLoopScheduler));
flowScheduler.add(practiceLoopScheduler);
flowScheduler.add(practiceLoopEnd);





flowScheduler.add(practiceEndRoutineBegin());
flowScheduler.add(practiceEndRoutineEachFrame());
flowScheduler.add(practiceEndRoutineEnd());
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin(trialsLoopScheduler));
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);






flowScheduler.add(theEndRoutineBegin());
flowScheduler.add(theEndRoutineEachFrame());
flowScheduler.add(theEndRoutineEnd());
flowScheduler.add(quitPsychoJS, '실험이 끝났습니다.\n\n참여해 주셔서 감사합니다.', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '실험이 끝났습니다.\n\n참여해 주셔서 감사합니다.', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  });
  
psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.INFO);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2025.1.1';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  

  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);
  psychoJS.experiment.field_separator = '\t';


  return Scheduler.Event.NEXT;
}


var instructionsClock;
var instructionsText;
var instructionsKey;
var fixationClock;
var fixCross;
var sprClock;
var sprStim;
var sprKey;
var condFile;
var MASK;
var qCheckClock;
var qText;
var qHint;
var qResp;
var blankClock;
var blankText;
var practiceEndClock;
var practiceEndText;
var practiceEndKey;
var breakRestClock;
var breakText;
var breakKey;
var theEndClock;
var endText;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  instructionsText = new visual.TextStim({
    win: psychoJS.window,
    name: 'instructionsText',
    text: "어절 단위 자기조절 읽기 과제\n\n화면에 문장이 '―――' 로 가려져 나옵니다.\n스페이스 바를 누를 때마다 어절이 하나씩 열리고, 앞 어절은 다시 가려집니다.\n\n자연스러운 속도로, 내용을 이해하면서 읽어 주세요.\n일부 문장 뒤에는 내용을 묻는 질문이 나옵니다.\n\n참(맞다) = F 키          거짓(틀리다) = J 키\n\n먼저 연습을 합니다. 준비되면 스페이스 바를 누르세요.",
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  instructionsKey = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "fixation"
  fixationClock = new util.Clock();
  fixCross = new visual.TextStim({
    win: psychoJS.window,
    name: 'fixCross',
    text: '+',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.08,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "spr"
  sprClock = new util.Clock();
  sprStim = new visual.TextStim({
    win: psychoJS.window,
    name: 'sprStim',
    text: '',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.055,  wrapWidth: 1.8, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  sprKey = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Run 'Begin Experiment' code from sprCode
  condFile = 'conditions/exp1_list' + expInfo['list'] + '.xlsx';
  MASK = '―';
  
  // Initialize components for Routine "qCheck"
  qCheckClock = new util.Clock();
  qText = new visual.TextStim({
    win: psychoJS.window,
    name: 'qText',
    text: '',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0.1], draggable: false, height: 0.06,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  qHint = new visual.TextStim({
    win: psychoJS.window,
    name: 'qHint',
    text: '참 = F                    거짓 = J',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, (- 0.2)], draggable: false, height: 0.04,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('lightgray'),  opacity: undefined,
    depth: -2.0 
  });
  
  qResp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "blank"
  blankClock = new util.Clock();
  blankText = new visual.TextStim({
    win: psychoJS.window,
    name: 'blankText',
    text: '',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.05,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "practiceEnd"
  practiceEndClock = new util.Clock();
  practiceEndText = new visual.TextStim({
    win: psychoJS.window,
    name: 'practiceEndText',
    text: '연습이 끝났습니다.\n\n본 실험은 총 72개 문장이며, 중간에 한 번 쉬는 시간이 있습니다.\n\n준비되면 스페이스 바를 눌러 시작하세요.',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  practiceEndKey = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "breakRest"
  breakRestClock = new util.Clock();
  breakText = new visual.TextStim({
    win: psychoJS.window,
    name: 'breakText',
    text: '잠시 쉬어 가세요.\n\n계속하려면 스페이스 바를 누르세요.',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.045,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  breakKey = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "theEnd"
  theEndClock = new util.Clock();
  endText = new visual.TextStim({
    win: psychoJS.window,
    name: 'endText',
    text: '실험이 끝났습니다.\n\n참여해 주셔서 감사합니다.',
    font: 'Malgun Gothic',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.05,  wrapWidth: 1.7, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var routineForceEnded;
var instructionsMaxDurationReached;
var _instructionsKey_allKeys;
var instructionsMaxDuration;
var instructionsComponents;
function instructionsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    instructionsClock.reset();
    routineTimer.reset();
    instructionsMaxDurationReached = false;
    // update component parameters for each repeat
    instructionsKey.keys = undefined;
    instructionsKey.rt = undefined;
    _instructionsKey_allKeys = [];
    psychoJS.experiment.addData('instructions.started', globalClock.getTime());
    instructionsMaxDuration = null
    // keep track of which components have finished
    instructionsComponents = [];
    instructionsComponents.push(instructionsText);
    instructionsComponents.push(instructionsKey);
    
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function instructionsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions' ---
    // get current time
    t = instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instructionsText* updates
    if (t >= 0.0 && instructionsText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instructionsText.tStart = t;  // (not accounting for frame time here)
      instructionsText.frameNStart = frameN;  // exact frame index
      
      instructionsText.setAutoDraw(true);
    }
    
    
    // if instructionsText is active this frame...
    if (instructionsText.status === PsychoJS.Status.STARTED) {
    }
    
    
    // *instructionsKey* updates
    if (t >= 0.0 && instructionsKey.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instructionsKey.tStart = t;  // (not accounting for frame time here)
      instructionsKey.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { instructionsKey.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { instructionsKey.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { instructionsKey.clearEvents(); });
    }
    
    // if instructionsKey is active this frame...
    if (instructionsKey.status === PsychoJS.Status.STARTED) {
      let theseKeys = instructionsKey.getKeys({keyList: 'space', waitRelease: false});
      _instructionsKey_allKeys = _instructionsKey_allKeys.concat(theseKeys);
      if (_instructionsKey_allKeys.length > 0) {
        instructionsKey.keys = _instructionsKey_allKeys[_instructionsKey_allKeys.length - 1].name;  // just the last key pressed
        instructionsKey.rt = _instructionsKey_allKeys[_instructionsKey_allKeys.length - 1].rt;
        instructionsKey.duration = _instructionsKey_allKeys[_instructionsKey_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructionsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions' ---
    for (const thisComponent of instructionsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('instructions.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(instructionsKey.corr, level);
    }
    psychoJS.experiment.addData('instructionsKey.keys', instructionsKey.keys);
    if (typeof instructionsKey.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('instructionsKey.rt', instructionsKey.rt);
        psychoJS.experiment.addData('instructionsKey.duration', instructionsKey.duration);
        routineTimer.reset();
        }
    
    instructionsKey.stop();
    // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var practice;
function practiceLoopBegin(practiceLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    practice = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'conditions/practice.xlsx',
      seed: undefined, name: 'practice'
    });
    psychoJS.experiment.addLoop(practice); // add the loop to the experiment
    currentLoop = practice;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisPractice of practice) {
      snapshot = practice.getSnapshot();
      practiceLoopScheduler.add(importConditions(snapshot));
      practiceLoopScheduler.add(fixationRoutineBegin(snapshot));
      practiceLoopScheduler.add(fixationRoutineEachFrame());
      practiceLoopScheduler.add(fixationRoutineEnd(snapshot));
      practiceLoopScheduler.add(sprRoutineBegin(snapshot));
      practiceLoopScheduler.add(sprRoutineEachFrame());
      practiceLoopScheduler.add(sprRoutineEnd(snapshot));
      practiceLoopScheduler.add(qCheckRoutineBegin(snapshot));
      practiceLoopScheduler.add(qCheckRoutineEachFrame());
      practiceLoopScheduler.add(qCheckRoutineEnd(snapshot));
      practiceLoopScheduler.add(blankRoutineBegin(snapshot));
      practiceLoopScheduler.add(blankRoutineEachFrame());
      practiceLoopScheduler.add(blankRoutineEnd(snapshot));
      practiceLoopScheduler.add(practiceLoopEndIteration(practiceLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function practiceLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(practice);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function practiceLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: condFile,
      seed: undefined, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial of trials) {
      snapshot = trials.getSnapshot();
      trialsLoopScheduler.add(importConditions(snapshot));
      trialsLoopScheduler.add(breakRestRoutineBegin(snapshot));
      trialsLoopScheduler.add(breakRestRoutineEachFrame());
      trialsLoopScheduler.add(breakRestRoutineEnd(snapshot));
      trialsLoopScheduler.add(fixationRoutineBegin(snapshot));
      trialsLoopScheduler.add(fixationRoutineEachFrame());
      trialsLoopScheduler.add(fixationRoutineEnd(snapshot));
      trialsLoopScheduler.add(sprRoutineBegin(snapshot));
      trialsLoopScheduler.add(sprRoutineEachFrame());
      trialsLoopScheduler.add(sprRoutineEnd(snapshot));
      trialsLoopScheduler.add(qCheckRoutineBegin(snapshot));
      trialsLoopScheduler.add(qCheckRoutineEachFrame());
      trialsLoopScheduler.add(qCheckRoutineEnd(snapshot));
      trialsLoopScheduler.add(blankRoutineBegin(snapshot));
      trialsLoopScheduler.add(blankRoutineEachFrame());
      trialsLoopScheduler.add(blankRoutineEnd(snapshot));
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var fixationMaxDurationReached;
var fixationMaxDuration;
var fixationComponents;
function fixationRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'fixation' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    fixationClock.reset(routineTimer.getTime());
    routineTimer.add(0.500000);
    fixationMaxDurationReached = false;
    // update component parameters for each repeat
    psychoJS.experiment.addData('fixation.started', globalClock.getTime());
    fixationMaxDuration = null
    // keep track of which components have finished
    fixationComponents = [];
    fixationComponents.push(fixCross);
    
    for (const thisComponent of fixationComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function fixationRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'fixation' ---
    // get current time
    t = fixationClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *fixCross* updates
    if (t >= 0.0 && fixCross.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fixCross.tStart = t;  // (not accounting for frame time here)
      fixCross.frameNStart = frameN;  // exact frame index
      
      fixCross.setAutoDraw(true);
    }
    
    
    // if fixCross is active this frame...
    if (fixCross.status === PsychoJS.Status.STARTED) {
    }
    
    frameRemains = 0.0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (fixCross.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      // keep track of stop time/frame for later
      fixCross.tStop = t;  // not accounting for scr refresh
      fixCross.frameNStop = frameN;  // exact frame index
      // update status
      fixCross.status = PsychoJS.Status.FINISHED;
      fixCross.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of fixationComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function fixationRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'fixation' ---
    for (const thisComponent of fixationComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('fixation.stopped', globalClock.getTime());
    if (routineForceEnded) {
        routineTimer.reset();} else if (fixationMaxDurationReached) {
        fixationClock.add(fixationMaxDuration);
    } else {
        fixationClock.add(0.500000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var sprMaxDurationReached;
var _sprKey_allKeys;
var words;
var nWords;
var masks;
var wordIdx;
var nPressed;
var sprRTs;
var lastRT;
var sprMaxDuration;
var sprComponents;
function sprRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'spr' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    sprClock.reset();
    routineTimer.reset();
    sprMaxDurationReached = false;
    // update component parameters for each repeat
    sprKey.keys = undefined;
    sprKey.rt = undefined;
    _sprKey_allKeys = [];
    // Run 'Begin Routine' code from sprCode
    words = sentence.split(' ');
    nWords = words.length;
    masks = words.map((w) => MASK.repeat(w.length));
    wordIdx = -1;
    nPressed = 0;
    sprRTs = [];
    lastRT = 0.0;
    sprStim.setText(masks.join(' '));
    
    psychoJS.experiment.addData('spr.started', globalClock.getTime());
    sprMaxDuration = null
    // keep track of which components have finished
    sprComponents = [];
    sprComponents.push(sprStim);
    sprComponents.push(sprKey);
    
    for (const thisComponent of sprComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function sprRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'spr' ---
    // get current time
    t = sprClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *sprStim* updates
    if (t >= 0.0 && sprStim.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sprStim.tStart = t;  // (not accounting for frame time here)
      sprStim.frameNStart = frameN;  // exact frame index
      
      sprStim.setAutoDraw(true);
    }
    
    
    // if sprStim is active this frame...
    if (sprStim.status === PsychoJS.Status.STARTED) {
    }
    
    
    // *sprKey* updates
    if (t >= 0.0 && sprKey.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sprKey.tStart = t;  // (not accounting for frame time here)
      sprKey.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { sprKey.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { sprKey.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { sprKey.clearEvents(); });
    }
    
    // if sprKey is active this frame...
    if (sprKey.status === PsychoJS.Status.STARTED) {
      let theseKeys = sprKey.getKeys({keyList: 'space', waitRelease: false});
      _sprKey_allKeys = _sprKey_allKeys.concat(theseKeys);
      if (_sprKey_allKeys.length > 0) {
        sprKey.keys = _sprKey_allKeys.map((key) => key.name);  // storing all keys
        sprKey.rt = _sprKey_allKeys.map((key) => key.rt);
        sprKey.duration = _sprKey_allKeys.map((key) => key.duration);
      }
    }
    
    // Run 'Each Frame' code from sprCode
    if (sprKey.rt !== undefined) {
        while (nPressed < sprKey.rt.length) {
            let thisRT = sprKey.rt[nPressed];
            nPressed += 1;
            if (wordIdx >= 0) {
                sprRTs.push(thisRT - lastRT);
            }
            lastRT = thisRT;
            wordIdx += 1;
            if (wordIdx >= nWords) {
                continueRoutine = false;
                break;
            }
            let disp = masks.slice();
            disp[wordIdx] = words[wordIdx];
            sprStim.setText(disp.join(' '));
        }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of sprComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function sprRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'spr' ---
    for (const thisComponent of sprComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('spr.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(sprKey.corr, level);
    }
    psychoJS.experiment.addData('sprKey.keys', sprKey.keys);
    if (typeof sprKey.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('sprKey.rt', sprKey.rt);
        psychoJS.experiment.addData('sprKey.duration', sprKey.duration);
        }
    
    sprKey.stop();
    // Run 'End Routine' code from sprCode
    for (let i = 0; i < 8; i++) {
        if (i < sprRTs.length) {
            psychoJS.experiment.addData('rt_w' + (i + 1), Math.round(sprRTs[i] * 10000) / 10);
        } else {
            psychoJS.experiment.addData('rt_w' + (i + 1), '');
        }
    }
    psychoJS.experiment.addData('rt_total', Math.round(sprRTs.reduce((a, b) => a + b, 0) * 10000) / 10);
    psychoJS.experiment.addData('nWordsRead', sprRTs.length);
    
    // the Routine "spr" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var qCheckMaxDurationReached;
var _qResp_allKeys;
var qCheckMaxDuration;
var qCheckComponents;
function qCheckRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'qCheck' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    qCheckClock.reset();
    routineTimer.reset();
    qCheckMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from qCode
    if (qFlag != 1) {
        continueRoutine = false;
    }
    
    qText.setText(question);
    qResp.keys = undefined;
    qResp.rt = undefined;
    _qResp_allKeys = [];
    psychoJS.experiment.addData('qCheck.started', globalClock.getTime());
    qCheckMaxDuration = null
    // keep track of which components have finished
    qCheckComponents = [];
    qCheckComponents.push(qText);
    qCheckComponents.push(qHint);
    qCheckComponents.push(qResp);
    
    for (const thisComponent of qCheckComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function qCheckRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'qCheck' ---
    // get current time
    t = qCheckClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *qText* updates
    if (t >= 0.0 && qText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      qText.tStart = t;  // (not accounting for frame time here)
      qText.frameNStart = frameN;  // exact frame index
      
      qText.setAutoDraw(true);
    }
    
    
    // if qText is active this frame...
    if (qText.status === PsychoJS.Status.STARTED) {
    }
    
    
    // *qHint* updates
    if (t >= 0.0 && qHint.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      qHint.tStart = t;  // (not accounting for frame time here)
      qHint.frameNStart = frameN;  // exact frame index
      
      qHint.setAutoDraw(true);
    }
    
    
    // if qHint is active this frame...
    if (qHint.status === PsychoJS.Status.STARTED) {
    }
    
    
    // *qResp* updates
    if (t >= 0.0 && qResp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      qResp.tStart = t;  // (not accounting for frame time here)
      qResp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { qResp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { qResp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { qResp.clearEvents(); });
    }
    
    // if qResp is active this frame...
    if (qResp.status === PsychoJS.Status.STARTED) {
      let theseKeys = qResp.getKeys({keyList: ['f','j'], waitRelease: false});
      _qResp_allKeys = _qResp_allKeys.concat(theseKeys);
      if (_qResp_allKeys.length > 0) {
        qResp.keys = _qResp_allKeys[_qResp_allKeys.length - 1].name;  // just the last key pressed
        qResp.rt = _qResp_allKeys[_qResp_allKeys.length - 1].rt;
        qResp.duration = _qResp_allKeys[_qResp_allKeys.length - 1].duration;
        // was this correct?
        if (qResp.keys == corrKey) {
            qResp.corr = 1;
        } else {
            qResp.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of qCheckComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function qCheckRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'qCheck' ---
    for (const thisComponent of qCheckComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('qCheck.stopped', globalClock.getTime());
    // was no response the correct answer?!
    if (qResp.keys === undefined) {
      if (['None','none',undefined].includes(corrKey)) {
         qResp.corr = 1;  // correct non-response
      } else {
         qResp.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(qResp.corr, level);
    }
    psychoJS.experiment.addData('qResp.keys', qResp.keys);
    psychoJS.experiment.addData('qResp.corr', qResp.corr);
    if (typeof qResp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('qResp.rt', qResp.rt);
        psychoJS.experiment.addData('qResp.duration', qResp.duration);
        routineTimer.reset();
        }
    
    qResp.stop();
    // the Routine "qCheck" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var blankMaxDurationReached;
var blankMaxDuration;
var blankComponents;
function blankRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'blank' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    blankClock.reset(routineTimer.getTime());
    routineTimer.add(0.800000);
    blankMaxDurationReached = false;
    // update component parameters for each repeat
    psychoJS.experiment.addData('blank.started', globalClock.getTime());
    blankMaxDuration = null
    // keep track of which components have finished
    blankComponents = [];
    blankComponents.push(blankText);
    
    for (const thisComponent of blankComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function blankRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'blank' ---
    // get current time
    t = blankClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *blankText* updates
    if (t >= 0.0 && blankText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      blankText.tStart = t;  // (not accounting for frame time here)
      blankText.frameNStart = frameN;  // exact frame index
      
      blankText.setAutoDraw(true);
    }
    
    
    // if blankText is active this frame...
    if (blankText.status === PsychoJS.Status.STARTED) {
    }
    
    frameRemains = 0.0 + 0.8 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (blankText.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      // keep track of stop time/frame for later
      blankText.tStop = t;  // not accounting for scr refresh
      blankText.frameNStop = frameN;  // exact frame index
      // update status
      blankText.status = PsychoJS.Status.FINISHED;
      blankText.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of blankComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function blankRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'blank' ---
    for (const thisComponent of blankComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('blank.stopped', globalClock.getTime());
    if (routineForceEnded) {
        routineTimer.reset();} else if (blankMaxDurationReached) {
        blankClock.add(blankMaxDuration);
    } else {
        blankClock.add(0.800000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var practiceEndMaxDurationReached;
var _practiceEndKey_allKeys;
var practiceEndMaxDuration;
var practiceEndComponents;
function practiceEndRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'practiceEnd' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    practiceEndClock.reset();
    routineTimer.reset();
    practiceEndMaxDurationReached = false;
    // update component parameters for each repeat
    practiceEndKey.keys = undefined;
    practiceEndKey.rt = undefined;
    _practiceEndKey_allKeys = [];
    psychoJS.experiment.addData('practiceEnd.started', globalClock.getTime());
    practiceEndMaxDuration = null
    // keep track of which components have finished
    practiceEndComponents = [];
    practiceEndComponents.push(practiceEndText);
    practiceEndComponents.push(practiceEndKey);
    
    for (const thisComponent of practiceEndComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function practiceEndRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'practiceEnd' ---
    // get current time
    t = practiceEndClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *practiceEndText* updates
    if (t >= 0.0 && practiceEndText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practiceEndText.tStart = t;  // (not accounting for frame time here)
      practiceEndText.frameNStart = frameN;  // exact frame index
      
      practiceEndText.setAutoDraw(true);
    }
    
    
    // if practiceEndText is active this frame...
    if (practiceEndText.status === PsychoJS.Status.STARTED) {
    }
    
    
    // *practiceEndKey* updates
    if (t >= 0.0 && practiceEndKey.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practiceEndKey.tStart = t;  // (not accounting for frame time here)
      practiceEndKey.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { practiceEndKey.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { practiceEndKey.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { practiceEndKey.clearEvents(); });
    }
    
    // if practiceEndKey is active this frame...
    if (practiceEndKey.status === PsychoJS.Status.STARTED) {
      let theseKeys = practiceEndKey.getKeys({keyList: 'space', waitRelease: false});
      _practiceEndKey_allKeys = _practiceEndKey_allKeys.concat(theseKeys);
      if (_practiceEndKey_allKeys.length > 0) {
        practiceEndKey.keys = _practiceEndKey_allKeys[_practiceEndKey_allKeys.length - 1].name;  // just the last key pressed
        practiceEndKey.rt = _practiceEndKey_allKeys[_practiceEndKey_allKeys.length - 1].rt;
        practiceEndKey.duration = _practiceEndKey_allKeys[_practiceEndKey_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of practiceEndComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practiceEndRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'practiceEnd' ---
    for (const thisComponent of practiceEndComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('practiceEnd.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(practiceEndKey.corr, level);
    }
    psychoJS.experiment.addData('practiceEndKey.keys', practiceEndKey.keys);
    if (typeof practiceEndKey.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('practiceEndKey.rt', practiceEndKey.rt);
        psychoJS.experiment.addData('practiceEndKey.duration', practiceEndKey.duration);
        routineTimer.reset();
        }
    
    practiceEndKey.stop();
    // the Routine "practiceEnd" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var breakRestMaxDurationReached;
var _breakKey_allKeys;
var breakRestMaxDuration;
var breakRestComponents;
function breakRestRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'breakRest' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    breakRestClock.reset();
    routineTimer.reset();
    breakRestMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from breakCode
    if (trials.thisN != 36) {
        continueRoutine = false;
    }
    
    breakKey.keys = undefined;
    breakKey.rt = undefined;
    _breakKey_allKeys = [];
    psychoJS.experiment.addData('breakRest.started', globalClock.getTime());
    breakRestMaxDuration = null
    // keep track of which components have finished
    breakRestComponents = [];
    breakRestComponents.push(breakText);
    breakRestComponents.push(breakKey);
    
    for (const thisComponent of breakRestComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function breakRestRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'breakRest' ---
    // get current time
    t = breakRestClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *breakText* updates
    if (t >= 0.0 && breakText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      breakText.tStart = t;  // (not accounting for frame time here)
      breakText.frameNStart = frameN;  // exact frame index
      
      breakText.setAutoDraw(true);
    }
    
    
    // if breakText is active this frame...
    if (breakText.status === PsychoJS.Status.STARTED) {
    }
    
    
    // *breakKey* updates
    if (t >= 0.0 && breakKey.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      breakKey.tStart = t;  // (not accounting for frame time here)
      breakKey.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { breakKey.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { breakKey.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { breakKey.clearEvents(); });
    }
    
    // if breakKey is active this frame...
    if (breakKey.status === PsychoJS.Status.STARTED) {
      let theseKeys = breakKey.getKeys({keyList: 'space', waitRelease: false});
      _breakKey_allKeys = _breakKey_allKeys.concat(theseKeys);
      if (_breakKey_allKeys.length > 0) {
        breakKey.keys = _breakKey_allKeys[_breakKey_allKeys.length - 1].name;  // just the last key pressed
        breakKey.rt = _breakKey_allKeys[_breakKey_allKeys.length - 1].rt;
        breakKey.duration = _breakKey_allKeys[_breakKey_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of breakRestComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function breakRestRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'breakRest' ---
    for (const thisComponent of breakRestComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('breakRest.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(breakKey.corr, level);
    }
    psychoJS.experiment.addData('breakKey.keys', breakKey.keys);
    if (typeof breakKey.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('breakKey.rt', breakKey.rt);
        psychoJS.experiment.addData('breakKey.duration', breakKey.duration);
        routineTimer.reset();
        }
    
    breakKey.stop();
    // the Routine "breakRest" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var theEndMaxDurationReached;
var theEndMaxDuration;
var theEndComponents;
function theEndRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'theEnd' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // keep track of whether this Routine was forcibly ended
    routineForceEnded = false;
    theEndClock.reset(routineTimer.getTime());
    routineTimer.add(3.000000);
    theEndMaxDurationReached = false;
    // update component parameters for each repeat
    psychoJS.experiment.addData('theEnd.started', globalClock.getTime());
    theEndMaxDuration = null
    // keep track of which components have finished
    theEndComponents = [];
    theEndComponents.push(endText);
    
    for (const thisComponent of theEndComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function theEndRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'theEnd' ---
    // get current time
    t = theEndClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *endText* updates
    if (t >= 0.0 && endText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      endText.tStart = t;  // (not accounting for frame time here)
      endText.frameNStart = frameN;  // exact frame index
      
      endText.setAutoDraw(true);
    }
    
    
    // if endText is active this frame...
    if (endText.status === PsychoJS.Status.STARTED) {
    }
    
    frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (endText.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      // keep track of stop time/frame for later
      endText.tStop = t;  // not accounting for scr refresh
      endText.frameNStop = frameN;  // exact frame index
      // update status
      endText.status = PsychoJS.Status.FINISHED;
      endText.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      routineForceEnded = true;
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of theEndComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function theEndRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'theEnd' ---
    for (const thisComponent of theEndComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('theEnd.stopped', globalClock.getTime());
    if (routineForceEnded) {
        routineTimer.reset();} else if (theEndMaxDurationReached) {
        theEndClock.add(theEndMaxDuration);
    } else {
        theEndClock.add(3.000000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
