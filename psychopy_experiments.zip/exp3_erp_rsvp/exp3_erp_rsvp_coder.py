# -*- coding: utf-8 -*-
"""
실험 3 · 통합 비용의 ERP — 어절 단위 RSVP + 병렬 포트 트리거   [Coder 버전]
=============================================================================
Builder 로 만든 exp3_erp_rsvp.psyexp 와 같은 절차를 직접 코딩한 스크립트.

절차 (시행마다)
  응시점 500 ms → 어절마다 350 ms 제시 + 150 ms 공백 (어절 N 까지)
  → 이해 점검 질문 (qFlag==1, 참=F / 거짓=J) → 공백 1000–1400 ms 무선

트리거 (병렬 포트, 화면 갱신(flip)에 동기화)
  trigStart  문장 시작(응시점 개시)   A=10 / B=20 / C=30 / 필러 90 / 연습 80
  trig1..N   각 어절 개시             조건코드×10 + 어절 번호  (임계 어절 = 15 / 25 / 35)
  trigQ      질문 제시 200,  반응 201(참) / 202(거짓)
  트리거는 1 프레임(≈16 ms) 뒤 자동으로 0 으로 돌아간다. 반응 트리거는 10 ms 펄스.

대화상자
  triggers = y/n  (n 이면 포트 없이 실행하고 로그에만 TRIGGER 기록 → 행동 파일럿)
  port     = 병렬 포트 주소 (16진수, 예: 0x0378, 0xD010)

측정치
  onset_w1..8 : 각 어절이 실제로 화면에 나타난 시각(시행 시작 기준, ms) — 타이밍 QA 용
  qResp, qRT, qAcc

실행:  Standalone PsychoPy Coder 에서 Run, 또는
       "C:\\Program Files\\PsychoPy\\python.exe" exp3_erp_rsvp_coder.py
"""
import os
import random

from psychopy import core, data, gui, logging, visual
from psychopy.hardware import keyboard

# ----------------------------------------------------------------------------
# 설정
# ----------------------------------------------------------------------------
EXP_NAME = 'exp3_erp_rsvp'
N_LISTS = 3
FONT = 'Malgun Gothic'
FIX_DUR = 0.5
WORD_ON = 0.35
WORD_OFF = 0.15
ITI_RANGE = (1.0, 1.4)
BREAK_AT = 36
ADVANCE_KEY = 'space'
ANS_KEYS = ['f', 'j']
TRIG_RESP = {'f': 201, 'j': 202}
RESP_PULSE = 0.01
FULLSCREEN = True

INSTR = (
    "어절 단위 읽기 과제 (EEG)\n\n"
    "화면 가운데 '+' 가 나온 뒤 문장이 어절 하나씩 자동으로 제시됩니다.\n"
    "눈을 움직이지 말고 가운데를 응시한 채 문장을 읽어 주세요.\n"
    "문장이 나오는 동안에는 눈을 깜박이지 말고, 질문이나 빈 화면에서 깜박여 주세요.\n\n"
    "일부 문장 뒤에는 내용을 묻는 질문이 나옵니다.\n\n"
    "참(맞다) = F 키          거짓(틀리다) = J 키\n\n"
    "먼저 연습을 합니다. 준비되면 스페이스 바를 누르세요."
)
PRAC_END = ("연습이 끝났습니다.\n\n본 실험은 총 72개 문장이며, 중간에 한 번 쉬는 시간이 있습니다.\n\n"
            "준비되면 스페이스 바를 눌러 시작하세요.")
BREAK_TXT = "잠시 쉬어 가세요.\n\n계속하려면 스페이스 바를 누르세요."
END_TXT = "실험이 끝났습니다.\n\n참여해 주셔서 감사합니다."
Q_HINT = "참 = F                    거짓 = J"

_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# ----------------------------------------------------------------------------
# 참가자 정보
# ----------------------------------------------------------------------------
expInfo = {'participant': '', 'list': '1', 'session': '001', 'triggers': 'n', 'port': '0x0378'}
dlg = gui.DlgFromDict(expInfo, title=EXP_NAME,
                      order=['participant', 'list', 'session', 'triggers', 'port'])
if not dlg.OK:
    core.quit()
expInfo['date'] = data.getDateStr()
expInfo['expName'] = EXP_NAME
listNo = int(expInfo['list'])
assert 1 <= listNo <= N_LISTS, 'list 는 1~%d' % N_LISTS

dataDir = os.path.join(_thisDir, 'data')
os.makedirs(dataDir, exist_ok=True)
filename = os.path.join(dataDir, '%s_%s_%s' % (expInfo['participant'], EXP_NAME, expInfo['date']))
thisExp = data.ExperimentHandler(name=EXP_NAME, extraInfo=expInfo, dataFileName=filename,
                                 savePickle=True, saveWideText=True)
logFile = logging.LogFile(filename + '.log', level=logging.DATA)
logging.console.setLevel(logging.WARNING)

# ----------------------------------------------------------------------------
# 병렬 포트
# ----------------------------------------------------------------------------
port = None
if str(expInfo['triggers']).strip().lower().startswith('y'):
    from psychopy import parallel
    port = parallel.ParallelPort(address=int(str(expInfo['port']), 16))
    port.setData(0)

trigState = {'reset': False}


def sendTrig(code, pulse=None):
    """트리거 전송 + 로그. pulse=None 이면 다음 flip 에 자동 리셋, 아니면 pulse 초 뒤 즉시 리셋."""
    if code in (None, ''):
        return
    code = int(code)
    if port is not None:
        port.setData(code)
    logging.data('TRIGGER %d' % code)
    if pulse is not None:
        core.wait(pulse)
        if port is not None:
            port.setData(0)
    elif code != 0:
        trigState['reset'] = True


def reset_trigger_if_pending():
    """직전 flip 에 보낸 트리거를 이번 flip 에 0 으로 되돌린다 (1 프레임 펄스)."""
    if trigState['reset']:
        trigState['reset'] = False
        if port is not None:
            win.callOnFlip(port.setData, 0)


# ----------------------------------------------------------------------------
# 창·자극·장치
# ----------------------------------------------------------------------------
win = visual.Window(fullscr=FULLSCREEN, size=(1280, 720), color='black', units='height',
                    allowGUI=False)
win.mouseVisible = False
frameDur = win.monitorFramePeriod or (1.0 / 60)
tol = frameDur * 0.5

kb = keyboard.Keyboard()
msgStim = visual.TextStim(win, text='', font=FONT, height=0.04, wrapWidth=1.7, color='white')
wordStim = visual.TextStim(win, text='', font=FONT, height=0.07, color='white')
qStim = visual.TextStim(win, text='', font=FONT, height=0.06, wrapWidth=1.7, pos=(0, 0.1), color='white')
qHint = visual.TextStim(win, text=Q_HINT, font=FONT, height=0.04, pos=(0, -0.2), color='lightgray')


def check_escape():
    if kb.getKeys(['escape'], waitRelease=False):
        if port is not None:
            port.setData(0)
        thisExp.saveAsWideText(filename + '.csv')
        thisExp.saveAsPickle(filename)
        win.close()
        core.quit()


def show_message(text, keys=(ADVANCE_KEY,)):
    msgStim.text = text
    msgStim.draw()
    win.flip()
    kb.clearEvents()
    while True:
        check_escape()
        if kb.getKeys(list(keys), waitRelease=False):
            break
        msgStim.draw()
        win.flip()


def show_blank(seconds):
    clock = core.Clock()
    while win.getFutureFlipTime(clock=clock) < seconds - tol:
        check_escape()
        reset_trigger_if_pending()
        win.flip()


# ----------------------------------------------------------------------------
# RSVP 시행
# ----------------------------------------------------------------------------
def rsvp_sentence(trial):
    """응시점 + 어절 RSVP. 각 어절의 실제 화면 개시 시각(s, 시행 시작 기준)을 돌려준다."""
    words = trial['sentence'].split(' ')
    nWords = len(words)
    # (개시 시각, 표시 문자열, 트리거) 일정표
    schedule = [(0.0, '+', trial['trigStart'])]
    for i, w in enumerate(words):
        onset = FIX_DUR + i * (WORD_ON + WORD_OFF)
        schedule.append((onset, w, trial.get('trig%d' % (i + 1))))
        schedule.append((onset + WORD_ON, '', None))
    tEnd = FIX_DUR + nWords * (WORD_ON + WORD_OFF)

    onsets = {}
    clock = core.Clock()

    def stamp(idx):
        onsets[idx] = clock.getTime()

    seg = 0
    wordIdx = 0
    while True:
        check_escape()
        reset_trigger_if_pending()
        tNext = win.getFutureFlipTime(clock=clock)
        if seg < len(schedule) and tNext >= schedule[seg][0] - tol:
            onset, txt, trig = schedule[seg]
            wordStim.text = txt
            if trig not in (None, ''):
                win.callOnFlip(sendTrig, trig)
            if txt and txt != '+':
                wordIdx += 1
                win.callOnFlip(stamp, wordIdx)
            seg += 1
        if tNext >= tEnd - tol:
            break
        wordStim.draw()
        win.flip()
    return onsets, nWords


def comprehension_question(trial):
    qStim.text = trial['question']
    qStim.draw()
    qHint.draw()
    win.callOnFlip(kb.clock.reset)
    win.callOnFlip(kb.clearEvents, eventType='keyboard')
    win.callOnFlip(sendTrig, trial['trigQ'])
    win.flip()
    while True:
        check_escape()
        reset_trigger_if_pending()
        keys = kb.getKeys(ANS_KEYS, waitRelease=False)
        if keys:
            k = keys[0]
            sendTrig(TRIG_RESP[k.name], pulse=RESP_PULSE)
            return k.name, k.rt, int(k.name == str(trial['corrKey']))
        qStim.draw()
        qHint.draw()
        win.flip()


def run_trial(trial):
    onsets, nWords = rsvp_sentence(trial)
    for i in range(8):
        thisExp.addData('onset_w%d' % (i + 1),
                        round(onsets[i + 1] * 1000, 1) if (i + 1) in onsets else '')
    thisExp.addData('nWordsShown', nWords)

    if int(trial.get('qFlag') or 0) == 1:
        resp, rt, acc = comprehension_question(trial)
        thisExp.addData('qResp', resp)
        thisExp.addData('qRT', round(rt * 1000, 1))
        thisExp.addData('qAcc', acc)

    iti = random.uniform(*ITI_RANGE)
    thisExp.addData('itiDur', round(iti * 1000, 1))
    show_blank(iti)


def run_block(condFile, name, break_at=None):
    trials = data.TrialHandler(trialList=data.importConditions(condFile), nReps=1,
                               method='random', name=name, extraInfo=expInfo)
    thisExp.addLoop(trials)
    for trial in trials:
        if break_at is not None and trials.thisN == break_at:
            show_message(BREAK_TXT)
        run_trial(trial)
        thisExp.nextEntry()


# ----------------------------------------------------------------------------
# 실험 흐름
# ----------------------------------------------------------------------------
show_message(INSTR)
run_block('conditions/practice.xlsx', 'practice')
show_message(PRAC_END)
run_block('conditions/exp3_list%d.xlsx' % listNo, 'trials', break_at=BREAK_AT)

msgStim.text = END_TXT
msgStim.draw()
win.flip()
core.wait(3.0)

if port is not None:
    port.setData(0)
thisExp.saveAsWideText(filename + '.csv')
thisExp.saveAsPickle(filename)
logging.flush()
win.close()
core.quit()
