# -*- coding: utf-8 -*-
"""
Builder(.psyexp) 생성 + Coder(.py)/PsychoJS(.js) 컴파일
--------------------------------------------------------
PsychoPy 의 experiment API 로 세 실험의 .psyexp 를 만들고,
PsychoPy 자체 컴파일러로 .py 와 html/*.js 를 생성한다.

실행 (Standalone PsychoPy 의 파이썬으로):
    "C:\\Program Files\\PsychoPy\\python.exe" tools/build_experiments.py
"""
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

from psychopy import experiment
from psychopy.experiment import loops
from psychopy.experiment.components.text import TextComponent
from psychopy.experiment.components.keyboard import KeyboardComponent
from psychopy.experiment.components.code import CodeComponent

FONT = 'Malgun Gothic'
MASK = '\u2015'   # '―'  가림 기호

# ----------------------------------------------------------------------------
# 공통 텍스트
# ----------------------------------------------------------------------------
INSTR_SPR = (
    "어절 단위 자기조절 읽기 과제\n\n"
    "화면에 문장이 '―――' 로 가려져 나옵니다.\n"
    "스페이스 바를 누를 때마다 어절이 하나씩 열리고, 앞 어절은 다시 가려집니다.\n\n"
    "자연스러운 속도로, 내용을 이해하면서 읽어 주세요.\n"
    "일부 문장 뒤에는 내용을 묻는 질문이 나옵니다.\n\n"
    "참(맞다) = F 키          거짓(틀리다) = J 키\n\n"
    "먼저 연습을 합니다. 준비되면 스페이스 바를 누르세요."
)
INSTR_RSVP = (
    "어절 단위 읽기 과제 (EEG)\n\n"
    "화면 가운데 '+' 가 나온 뒤 문장이 어절 하나씩 자동으로 제시됩니다.\n"
    "눈을 움직이지 말고 가운데를 응시한 채 문장을 읽어 주세요.\n"
    "문장이 나오는 동안에는 눈을 깜박이지 말고, 질문이나 빈 화면에서 깜박여 주세요.\n\n"
    "일부 문장 뒤에는 내용을 묻는 질문이 나옵니다.\n\n"
    "참(맞다) = F 키          거짓(틀리다) = J 키\n\n"
    "먼저 연습을 합니다. 준비되면 스페이스 바를 누르세요."
)
PRAC_END = (
    "연습이 끝났습니다.\n\n"
    "본 실험은 총 72개 문장이며, 중간에 한 번 쉬는 시간이 있습니다.\n\n"
    "준비되면 스페이스 바를 눌러 시작하세요."
)
BREAK_TXT = "잠시 쉬어 가세요.\n\n계속하려면 스페이스 바를 누르세요."
END_TXT = "실험이 끝났습니다.\n\n참여해 주셔서 감사합니다."
Q_HINT = "참 = F                    거짓 = J"


# ----------------------------------------------------------------------------
# 헬퍼
# ----------------------------------------------------------------------------
def set_param(comp, name, val, updates=None):
    p = comp.params[name]
    p.val = val
    if updates is not None:
        p.updates = updates


def add_text(routine, name, text, start=0.0, dur='', pos=(0, 0), height=0.05,
             updates='constant', wrap=1.7, color='white'):
    c = TextComponent(routine.exp, routine.name, name=name)
    set_param(c, 'text', text, updates)
    set_param(c, 'font', FONT)
    set_param(c, 'startVal', start)
    set_param(c, 'stopVal', dur)
    set_param(c, 'pos', pos)
    set_param(c, 'letterHeight', height)
    set_param(c, 'wrapWidth', wrap)
    set_param(c, 'color', color)
    routine.addComponent(c)
    return c


def add_key(routine, name, keys, start=0.0, dur='', force=True, store='last key',
            store_correct=False, correct_ans=''):
    c = KeyboardComponent(routine.exp, routine.name, name=name)
    set_param(c, 'allowedKeys', ','.join("'%s'" % k for k in keys))
    set_param(c, 'startVal', start)
    set_param(c, 'stopVal', dur)
    set_param(c, 'forceEndRoutine', force)
    set_param(c, 'store', store)
    set_param(c, 'storeCorrect', store_correct)
    set_param(c, 'correctAns', correct_ans)
    set_param(c, 'discard previous', True)
    routine.addComponent(c)
    return c


def add_code(routine, name, py=None, js=None):
    """py / js: dict with keys among
       'Before Experiment','Begin Experiment','Begin Routine','Each Frame','End Routine','End Experiment'"""
    c = CodeComponent(routine.exp, routine.name, name=name)
    set_param(c, 'Code Type', 'Both')
    for k, v in (py or {}).items():
        set_param(c, k, v)
    for k, v in (js or {}).items():
        jsk = k.replace('Begin ', 'Begin JS ').replace('Each ', 'Each JS ') \
               .replace('End ', 'End JS ').replace('Before ', 'Before JS ')
        set_param(c, jsk, v)
    routine.addComponent(c)
    return c


def new_experiment(exp_name, exp_info, resources, escape=True):
    exp = experiment.Experiment()
    exp.setExpName(exp_name)
    s = exp.settings.params
    s['expName'].val = exp_name
    s['Experiment info'].val = exp_info
    s['Full-screen window'].val = True
    s['Units'].val = 'height'
    s['Save wide csv file'].val = True
    s['Save csv file'].val = False
    s['Save excel file'].val = False
    s['Save psydat file'].val = True
    s['Save log file'].val = True
    s['Enable Escape'].val = escape
    s['Show mouse'].val = False
    s['color'].val = 'black'
    s['HTML path'].val = 'html'
    s['exportHTML'].val = 'on Sync'
    s['Resources'].val = list(resources)
    s['End Message'].val = END_TXT
    return exp


def instr_routine(exp, name, text, height=0.04):
    r = exp.addRoutine(name)
    add_text(r, name + 'Text', text, height=height)
    add_key(r, name + 'Key', ['space'])
    return r


def fix_routine(exp, dur=0.5):
    r = exp.addRoutine('fixation')
    add_text(r, 'fixCross', '+', dur=dur, height=0.08)
    return r


def blank_routine(exp, name, dur):
    r = exp.addRoutine(name)
    add_text(r, name + 'Text', '', dur=dur)
    return r


def break_routine(exp, loop_name='trials', at=36):
    r = exp.addRoutine('breakRest')
    add_code(r, 'breakCode',
             py={'Begin Routine':
                 "# 본실험 %d번째 시행 직전에만 쉬는 화면을 보여준다\n"
                 "if %s.thisN != %d:\n"
                 "    continueRoutine = False\n" % (at, loop_name, at)},
             js={'Begin Routine':
                 "if (%s.thisN != %d) {\n"
                 "    continueRoutine = false;\n"
                 "}\n" % (loop_name, at)})
    add_text(r, 'breakText', BREAK_TXT, height=0.045)
    add_key(r, 'breakKey', ['space'])
    return r


def question_routine(exp, with_trigger=False):
    """qFlag==0 이면 건너뛴다. f=참, j=거짓, corrKey 로 정오 판정."""
    r = exp.addRoutine('qCheck')
    py = {'Begin Routine':
          "# 이해 점검 질문이 없는 시행은 건너뛴다\n"
          "if qFlag != 1:\n"
          "    continueRoutine = False\n"}
    js = {'Begin Routine':
          "if (qFlag != 1) {\n"
          "    continueRoutine = false;\n"
          "}\n"}
    if with_trigger:
        py['Begin Routine'] += "qTrigSent = False\n"
        py['Each Frame'] = (
            "# 질문 화면 개시 트리거 (trigQ), 화면 갱신에 동기화\n"
            "if qText.status == STARTED and not qTrigSent:\n"
            "    win.callOnFlip(sendTrig, trigQ)\n"
            "    qTrigSent = True\n")
        py['End Routine'] = (
            "# 반응 트리거: 참=201, 거짓=202\n"
            "if qResp.keys == 'f':\n"
            "    sendTrig(201, pulse=0.01)\n"
            "elif qResp.keys == 'j':\n"
            "    sendTrig(202, pulse=0.01)\n")
        js['Each Frame'] = "// 온라인(PsychoJS)에서는 트리거를 보낼 수 없다\n"
        js['End Routine'] = "// 온라인(PsychoJS)에서는 트리거를 보낼 수 없다\n"
    add_code(r, 'qCode', py=py, js=js)
    add_text(r, 'qText', '$question', pos=(0, 0.1), height=0.06, updates='set every repeat')
    add_text(r, 'qHint', Q_HINT, pos=(0, -0.2), height=0.04, color='lightgray')
    corr = KeyboardComponent(exp, 'qCheck', name='tmp').params['correctAns']
    ans = 'corrKey' if corr.valType == 'code' else '$corrKey'
    add_key(r, 'qResp', ['f', 'j'], store='last key', store_correct=True, correct_ans=ans)
    return r


# ----------------------------------------------------------------------------
# 실험 1·2 : 자기조절 읽기 (비누적 이동창)
# ----------------------------------------------------------------------------
SPR_BEGIN_EXP_PY = """\
# 리스트 번호로 조건 파일을 고른다 (conditions/exp{n}_list1.xlsx ...)
condFile = 'conditions/exp{n}_list' + str(expInfo['list']) + '.xlsx'
MASK = '{mask}'   # 어절을 가리는 기호 (음절 수만큼 반복)
"""
SPR_BEGIN_EXP_JS = """\
condFile = 'conditions/exp{n}_list' + expInfo['list'] + '.xlsx';
MASK = '{mask}';
"""
SPR_BEGIN_ROUTINE_PY = """\
# 문장을 어절로 쪼개고 전부 가린 상태로 시작한다
words = sentence.split(' ')
nWords = len(words)
masks = [MASK * len(w) for w in words]
wordIdx = -1        # -1 = 아직 열린 어절 없음
nPressed = 0        # 처리한 스페이스 누름 수
sprRTs = []         # 어절별 읽기 시간(s): 어절 i 가 열린 뒤 다음 누름까지
lastRT = 0.0
sprStim.setText(' '.join(masks))
"""
SPR_BEGIN_ROUTINE_JS = """\
words = sentence.split(' ');
nWords = words.length;
masks = words.map((w) => MASK.repeat(w.length));
wordIdx = -1;
nPressed = 0;
sprRTs = [];
lastRT = 0.0;
sprStim.setText(masks.join(' '));
"""
SPR_EACH_FRAME_PY = """\
# 새로 들어온 스페이스 누름을 처리한다 (sprKey 는 'all keys' 저장 → rt 리스트 누적)
while nPressed < len(sprKey.rt):
    thisRT = sprKey.rt[nPressed]
    nPressed += 1
    if wordIdx >= 0:
        sprRTs.append(thisRT - lastRT)   # 직전 어절의 읽기 시간
    lastRT = thisRT
    wordIdx += 1
    if wordIdx >= nWords:
        continueRoutine = False           # 마지막 어절까지 읽음
        break
    disp = list(masks)
    disp[wordIdx] = words[wordIdx]        # 현재 어절만 열고 나머지는 가림
    sprStim.setText(' '.join(disp))
"""
SPR_EACH_FRAME_JS = """\
if (sprKey.rt !== undefined) {
    while (nPressed < sprKey.rt.length) {
        let thisRT = sprKey.rt[nPressed];
        nPressed += 1;
        if (wordIdx >= 0) {
            sprRTs.push(thisRT - lastRT);
        }
        lastRT = thisRT;
        wordIdx += 1;
        if (wordIdx >= nWords) {
            continueRoutine = false;
            break;
        }
        let disp = masks.slice();
        disp[wordIdx] = words[wordIdx];
        sprStim.setText(disp.join(' '));
    }
}
"""
SPR_END_ROUTINE_PY = """\
# 어절별 읽기 시간을 ms 단위로 저장 (rt_w1 ... rt_w8)
for i in range(8):
    if i < len(sprRTs):
        thisExp.addData('rt_w%d' % (i + 1), round(sprRTs[i] * 1000, 1))
    else:
        thisExp.addData('rt_w%d' % (i + 1), '')
thisExp.addData('rt_total', round(sum(sprRTs) * 1000, 1))
thisExp.addData('nWordsRead', len(sprRTs))
"""
SPR_END_ROUTINE_JS = """\
for (let i = 0; i < 8; i++) {
    if (i < sprRTs.length) {
        psychoJS.experiment.addData('rt_w' + (i + 1), Math.round(sprRTs[i] * 10000) / 10);
    } else {
        psychoJS.experiment.addData('rt_w' + (i + 1), '');
    }
}
psychoJS.experiment.addData('rt_total', Math.round(sprRTs.reduce((a, b) => a + b, 0) * 10000) / 10);
psychoJS.experiment.addData('nWordsRead', sprRTs.length);
"""


def build_spr(exp_no, n_lists, exp_name, folder):
    resources = ['conditions/practice.xlsx'] + \
                ['conditions/exp%d_list%d.xlsx' % (exp_no, k) for k in range(1, n_lists + 1)]
    exp_info = "{'participant': '', 'list': '1', 'session': '001'}"
    exp = new_experiment(exp_name, exp_info, resources)

    # --- routines
    instr = instr_routine(exp, 'instructions', INSTR_SPR)
    fix = fix_routine(exp, 0.5)

    spr = exp.addRoutine('spr')
    add_code(spr, 'sprCode',
             py={'Begin Experiment': SPR_BEGIN_EXP_PY.format(n=exp_no, mask=MASK),
                 'Begin Routine': SPR_BEGIN_ROUTINE_PY,
                 'Each Frame': SPR_EACH_FRAME_PY,
                 'End Routine': SPR_END_ROUTINE_PY},
             js={'Begin Experiment': SPR_BEGIN_EXP_JS.format(n=exp_no, mask=MASK),
                 'Begin Routine': SPR_BEGIN_ROUTINE_JS,
                 'Each Frame': SPR_EACH_FRAME_JS,
                 'End Routine': SPR_END_ROUTINE_JS})
    # 키보드가 코드보다 먼저 폴링되도록 코드 컴포넌트를 마지막으로 옮긴다
    add_text(spr, 'sprStim', '', height=0.055, wrap=1.8)
    add_key(spr, 'sprKey', ['space'], force=False, store='all keys')
    code = spr.pop(spr.index(exp.getComponentFromName('sprCode')))
    spr.append(code)

    q = question_routine(exp)
    blank = blank_routine(exp, 'blank', 0.8)
    prac_end = instr_routine(exp, 'practiceEnd', PRAC_END)
    brk = break_routine(exp, 'trials', 36)
    end = exp.addRoutine('theEnd')
    add_text(end, 'endText', END_TXT, dur=3.0, height=0.05)

    # --- flow
    prac_loop = loops.TrialHandler(exp, name='practice', loopType='random', nReps=1,
                                   conditionsFile='conditions/practice.xlsx')
    main_loop = loops.TrialHandler(exp, name='trials', loopType='random', nReps=1,
                                   conditionsFile='$condFile')
    flow = exp.flow
    seq = [instr, fix, spr, q, blank, prac_end, brk, fix, spr, q, blank, end]
    for i, r in enumerate(seq):
        flow.addRoutine(r, i)
    # practice loop: fix..blank (index 1..4)  -> initiator at 1, terminator after index 4
    flow.addLoop(prac_loop, 1, 5)
    # after insertion: [instr, INIT, fix, spr, q, blank, TERM, prac_end, brk, fix, spr, q, blank, end]
    flow.addLoop(main_loop, 8, 13)
    return exp


# ----------------------------------------------------------------------------
# 실험 3 : 어절 단위 RSVP + 병렬 포트 트리거 (ERP)
# ----------------------------------------------------------------------------
WORD_ON = 0.35
WORD_OFF = 0.15
FIX_DUR = 0.5

RSVP_BEGIN_EXP_PY = """\
condFile = 'conditions/exp3_list' + str(expInfo['list']) + '.xlsx'

# --- 병렬 포트 트리거 ---------------------------------------------------
# expInfo['triggers'] 가 'y' 이면 expInfo['port'] 주소(16진수)로 병렬 포트를 연다.
# 'n' 이면 트리거 없이 (행동 파일럿용) 실행하고 로그에만 기록한다.
useTriggers = str(expInfo['triggers']).strip().lower().startswith('y')
port = None
if useTriggers:
    from psychopy import parallel
    port = parallel.ParallelPort(address=int(str(expInfo['port']), 16))
    port.setData(0)

trigState = {'reset': False}   # 다음 프레임에 0 으로 되돌릴지 여부

def sendTrig(code, pulse=None):
    # 트리거 값을 보내고 로그에 남긴다.
    #   pulse=None : 화면 갱신에 동기화된 트리거. 다음 프레임(flip)에 자동으로 0 을 보낸다.
    #   pulse=초   : 즉시 보내고 그 시간만큼 기다린 뒤 바로 0 으로 되돌린다 (반응 트리거용).
    if code in (None, ''):
        return
    code = int(code)
    if port is not None:
        port.setData(code)
    logging.data('TRIGGER %d' % code)
    if pulse is not None:
        core.wait(pulse)
        if port is not None:
            port.setData(0)
    elif code != 0:
        trigState['reset'] = True
"""
RSVP_BEGIN_EXP_JS = """\
condFile = 'conditions/exp3_list' + expInfo['list'] + '.xlsx';
// 온라인(PsychoJS)에서는 병렬 포트 트리거를 보낼 수 없다 (행동 데이터만 수집)
"""
RSVP_BEGIN_ROUTINE_PY = """\
words = sentence.split(' ')
nWords = len(words)
wordStims = [word1, word2, word3, word4, word5, word6, word7, word8]
trigCodes = [trig1, trig2, trig3, trig4, trig5, trig6, trig7, trig8]
for i in range(8):
    wordStims[i].setText(words[i] if i < nWords else '')
trigSent = [False] * 8
startSent = False
rsvpEnd = FIX_DUR + nWords * (WORD_ON + WORD_OFF)   # 마지막 어절 공백까지
""".replace('FIX_DUR', repr(FIX_DUR)).replace('WORD_ON', repr(WORD_ON)).replace('WORD_OFF', repr(WORD_OFF))
RSVP_BEGIN_ROUTINE_JS = """\
words = sentence.split(' ');
nWords = words.length;
wordStims = [word1, word2, word3, word4, word5, word6, word7, word8];
for (let i = 0; i < 8; i++) {
    wordStims[i].setText((i < nWords) ? words[i] : '');
}
rsvpEnd = FIX_DUR + nWords * (WORD_ON + WORD_OFF);
""".replace('FIX_DUR', repr(FIX_DUR)).replace('WORD_ON', repr(WORD_ON)).replace('WORD_OFF', repr(WORD_OFF))
RSVP_EACH_FRAME_PY = """\
# 직전 프레임에 보낸 트리거를 0으로 되돌린다 (약 1프레임 길이의 펄스)
if trigState['reset']:
    trigState['reset'] = False
    if port is not None:
        win.callOnFlip(port.setData, 0)
# 응시점 개시 = 문장 시작 트리거 (trigStart)
if fixCross.status == STARTED and not startSent:
    win.callOnFlip(sendTrig, trigStart)
    startSent = True
# 각 어절이 화면에 처음 그려지는 flip 에 맞춰 trig1..trigN 전송
for i in range(nWords):
    if wordStims[i].status == STARTED and not trigSent[i]:
        win.callOnFlip(sendTrig, trigCodes[i])
        trigSent[i] = True
# 마지막 어절의 공백까지 끝나면 루틴 종료
if tThisFlip >= rsvpEnd - frameTolerance:
    continueRoutine = False
"""
RSVP_EACH_FRAME_JS = """\
if (t >= rsvpEnd) {
    continueRoutine = false;
}
"""
RSVP_END_EXP_PY = """\
if port is not None:
    port.setData(0)
"""
ITI_BEGIN_PY = "itiDur = 1.0 + 0.4 * random()   # 1000~1400 ms 무선\n"
ITI_BEGIN_JS = "itiDur = 1.0 + 0.4 * Math.random();\n"


def build_rsvp(exp_name, folder):
    n_lists = 3
    resources = ['conditions/practice.xlsx'] + \
                ['conditions/exp3_list%d.xlsx' % k for k in range(1, n_lists + 1)]
    exp_info = "{'participant': '', 'list': '1', 'session': '001', 'triggers': 'n', 'port': '0x0378'}"
    exp = new_experiment(exp_name, exp_info, resources)

    instr = instr_routine(exp, 'instructions', INSTR_RSVP)

    rsvp = exp.addRoutine('rsvp')
    add_text(rsvp, 'fixCross', '+', start=0.0, dur=FIX_DUR, height=0.08)
    for i in range(8):
        onset = FIX_DUR + i * (WORD_ON + WORD_OFF)
        add_text(rsvp, 'word%d' % (i + 1), '', start=round(onset, 3), dur=WORD_ON, height=0.07)
    add_code(rsvp, 'rsvpCode',
             py={'Begin Experiment': RSVP_BEGIN_EXP_PY,
                 'Begin Routine': RSVP_BEGIN_ROUTINE_PY,
                 'Each Frame': RSVP_EACH_FRAME_PY,
                 'End Experiment': RSVP_END_EXP_PY},
             js={'Begin Experiment': RSVP_BEGIN_EXP_JS,
                 'Begin Routine': RSVP_BEGIN_ROUTINE_JS,
                 'Each Frame': RSVP_EACH_FRAME_JS,
                 'End Experiment': ''})

    q = question_routine(exp, with_trigger=True)

    iti = exp.addRoutine('iti')
    add_code(iti, 'itiCode', py={'Begin Routine': ITI_BEGIN_PY}, js={'Begin Routine': ITI_BEGIN_JS})
    add_text(iti, 'itiBlank', '', dur='$itiDur')

    prac_end = instr_routine(exp, 'practiceEnd', PRAC_END)
    brk = break_routine(exp, 'trials', 36)
    end = exp.addRoutine('theEnd')
    add_text(end, 'endText', END_TXT, dur=3.0, height=0.05)

    prac_loop = loops.TrialHandler(exp, name='practice', loopType='random', nReps=1,
                                   conditionsFile='conditions/practice.xlsx')
    main_loop = loops.TrialHandler(exp, name='trials', loopType='random', nReps=1,
                                   conditionsFile='$condFile')
    flow = exp.flow
    seq = [instr, rsvp, q, iti, prac_end, brk, rsvp, q, iti, end]
    for i, r in enumerate(seq):
        flow.addRoutine(r, i)
    flow.addLoop(prac_loop, 1, 4)
    # [instr, INIT, rsvp, q, iti, TERM, prac_end, brk, rsvp, q, iti, end]
    flow.addLoop(main_loop, 7, 11)
    return exp


# ----------------------------------------------------------------------------
def _write(exp, outfile, target, modular=True):
    script = exp.writeScript(outfile, target=target, modular=modular)
    text = script if isinstance(script, str) else script.getvalue()
    with io.open(outfile, 'w', encoding='utf-8-sig') as f:
        f.write(text)
    print('compiled', os.path.relpath(outfile, ROOT))


def save_and_compile(exp, folder, exp_name):
    """psyexp 저장 후, 저장된 파일을 다시 읽어 Python / PsychoJS 스크립트를 쓴다.
    (psyexpCompile.compileScript 와 같은 절차이며, wx 없이 동작하도록 직접 호출한다.)"""
    out_dir = os.path.join(ROOT, folder)
    os.makedirs(os.path.join(out_dir, 'html'), exist_ok=True)
    psyexp = os.path.join(out_dir, exp_name + '.psyexp')
    exp.expPath = psyexp
    exp.filename = psyexp
    exp.saveToXML(psyexp)
    print('saved ', os.path.relpath(psyexp, ROOT))

    exp2 = experiment.Experiment()
    exp2.loadFromXML(psyexp)
    _write(exp2, os.path.join(out_dir, exp_name + '.py'), 'PsychoPy')
    js_out = os.path.join(out_dir, 'html', exp_name + '.js')
    _write(exp2, js_out, 'PsychoJS', modular=True)
    _write(exp2, js_out.replace('.js', '-legacy-browsers.js'), 'PsychoJS', modular=False)


def main():
    which = sys.argv[1:] or ['1', '2', '3']
    if '1' in which:
        save_and_compile(build_spr(1, 2, 'exp1_boundary_spr', 'exp1_boundary_spr'),
                         'exp1_boundary_spr', 'exp1_boundary_spr')
    if '2' in which:
        save_and_compile(build_spr(2, 3, 'exp2_dose_response_spr', 'exp2_dose_response_spr'),
                         'exp2_dose_response_spr', 'exp2_dose_response_spr')
    if '3' in which:
        save_and_compile(build_rsvp('exp3_erp_rsvp', 'exp3_erp_rsvp'),
                         'exp3_erp_rsvp', 'exp3_erp_rsvp')


if __name__ == '__main__':
    main()
