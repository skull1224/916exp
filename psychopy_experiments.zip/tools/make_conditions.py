# -*- coding: utf-8 -*-
"""
조건 파일 생성기
----------------
stimuli/expN_targets.xlsx (원본 목표 문항) + 아래의 필러·연습 문장을 합쳐
각 실험 폴더의 conditions/ 에 PsychoPy 루프용 xlsx 를 만든다.

  expN/conditions/expN_listK.xlsx   목표 24 + 필러 48 = 72행 (본실험 루프, random)
  expN/conditions/practice.xlsx     연습 8행
  stimuli/fillers.xlsx, stimuli/practice.xlsx   필러·연습 원본(수정용)

필러·연습 문장을 바꾸려면 아래 FILLERS / PRACTICE 를 고친 뒤 이 스크립트를 다시 실행한다.
    python tools/make_conditions.py
"""
import os
import openpyxl

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
STIM = os.path.join(ROOT, 'stimuli')

EXP_DIRS = {1: 'exp1_boundary_spr', 2: 'exp2_dose_response_spr', 3: 'exp3_erp_rsvp'}

# (문장, 질문, 정답)  정답 '참' -> f, '거짓' -> j, 질문 없으면 None
FILLERS = [
    ('아이들은 오후에 놀이터에서 신나게 공을 함께 찼다', '아이들이 공을 찼다.', '참'),
    ('할머니는 아침마다 마당에서 천천히 꽃에 물을 주신다', None, None),
    ('동생은 어젯밤 늦게까지 방에서 숙제를 열심히 했다', '동생이 숙제를 하지 않았다.', '거짓'),
    ('우리는 지난 주말 바다에서 하루 종일 수영을 즐겼다', None, None),
    ('형은 매일 저녁 공원에서 삼십 분 동안 달린다', None, None),
    ('선생님은 오늘 교실에서 새로운 단원을 자세히 설명하셨다', '선생님이 새로운 단원을 설명했다.', '참'),
    ('비가 갑자기 쏟아져서 사람들은 급히 처마 밑으로 뛰어갔다', None, None),
    ('엄마는 시장에서 사과와 배를 한 봉지씩 사셨다', None, None),
    ('그 식당은 점심시간마다 손님이 너무 많아서 늘 붐빈다', '그 식당은 점심시간에 한산하다.', '거짓'),
    ('기차는 정확히 아홉 시에 서울역을 조용히 출발했다', None, None),
    ('친구가 어제 전화로 다음주 여행계획을 알려 주었다', None, None),
    ('강아지는 주인이 돌아오자 꼬리를 흔들며 현관으로 달려갔다', '강아지가 꼬리를 흔들었다.', '참'),
    ('도서관은 시험기간에 매일 밤 열시까지 문을 연다', None, None),
    ('학생들은 방학 동안 봉사활동에 꾸준히 참여했다', None, None),
    ('아버지는 주말마다 낚시터에서 조용히 시간을 보내신다', None, None),
    ('새로 생긴 카페는 커피가 맛있어서 손님이 많다', '새로 생긴 카페는 손님이 적다.', '거짓'),
    ('누나는 지난달에 회사 근처로 이사를 했다', None, None),
    ('오늘 아침에는 안개가 심해서 앞이 잘 보이지 않았다', None, None),
    ('삼촌은 생일 선물로 조카에게 자전거를 사 주었다', '삼촌이 조카에게 자전거를 주었다.', '참'),
    ('회의는 예정보다 한 시간이나 늦게 끝났다', None, None),
    ('우리 반은 체육대회에서 줄다리기 종목에 출전했다', None, None),
    ('언니는 요즘 매일 저녁 요리 학원에 다닌다', None, None),
    ('마을 사람들은 명절을 앞두고 함께 골목을 청소했다', None, None),
    ('그는 버스를 놓쳐서 결국 택시를 타고 출근했다', None, None),
    ('올해 겨울이 되자 호수가 두껍게 얼어붙었다', None, None),
    ('소년은 도서관에서 빌린 책을 일주일 만에 다 읽었다', None, None),
    ('이모는 매주 토요일에 시골 부모님 댁을 찾아간다', None, None),
    ('공연이 끝나자 관객들은 일제히 일어나 박수를 쳤다', '관객들이 조용히 앉아 있었다.', '거짓'),
    ('시청 앞 광장에서는 주말마다 벼룩시장이 열린다', None, None),
    ('할아버지는 신문을 읽으시다가 안경을 벗고 잠시 쉬셨다', None, None),
    ('그 가게는 저녁 여덟 시가 되면 문을 닫는다', None, None),
    ('동네 아이들이 눈사람을 만들려고 눈을 열심히 굴렸다', '아이들이 눈사람을 만들려고 했다.', '참'),
    ('나는 어제 오랜만에 고향 친구에게 편지를 썼다', None, None),
    ('봄바람이 불자 벚꽃잎이 길 위로 흩날렸다', None, None),
    ('요리사는 손님 앞에서 능숙하게 생선을 손질했다', '요리사가 고기를 손질했다.', '거짓'),
    ('문구점은 새 학기를 맞아 물건을 새로 들여놓았다', None, None),
    ('우리 가족은 저녁마다 식탁에 모여 하루 이야기를 나눈다', None, None),
    ('경비원은 밤새 건물을 돌며 문단속을 확인했다', None, None),
    ('오빠는 면접을 앞두고 새 양복을 한 벌 샀다', None, None),
    ('농부들은 가을이 오자 바쁘게 벼를 거두어들였다', None, None),
    ('버스 정류장에는 우산을 든 사람들이 길게 줄을 섰다', None, None),
    ('어린 동생은 처음으로 혼자 자전거를 타는 데 성공했다', None, None),
    ('사장은 직원들에게 다음 달부터 재택근무를 허용하겠다고 말했다', '사장이 재택근무를 금지하겠다고 말했다.', '거짓'),
    ('태풍 때문에 오늘 예정된 야구 경기가 취소되었다', None, None),
    ('아기는 엄마 품에서 금세 새근새근 잠이 들었다', None, None),
    ('관광객들은 가이드를 따라 고궁을 천천히 둘러보았다', '관광객들이 고궁을 둘러보았다.', '참'),
    ('저녁 뉴스에서 내일 전국에 큰 눈이 내린다고 전했다', None, None),
    ('그녀는 창가에 앉아 오래된 사진첩을 조용히 넘겨보았다', None, None),
]

PRACTICE = [
    ('소녀는 아침에 학교에서 친구와 즐겁게 이야기했다', '소녀가 친구와 이야기했다.', '참'),
    ('삼촌은 지난 여름 제주도에서 일주일 동안 머물렀다', None, None),
    ('고양이가 창밖의 새를 오랫동안 가만히 지켜보았다', '고양이가 새를 잡았다.', '거짓'),
    ('우체부는 매일 아침 동네를 돌며 편지를 배달한다', None, None),
    ('학생들은 시험이 끝나자 운동장으로 우르르 몰려나갔다', None, None),
    ('어머니는 주방에서 저녁 식사를 정성껏 준비하셨다', None, None),
    ('그 배우는 새 영화에서 처음으로 악역을 맡았다', '그 배우가 악역을 맡았다.', '참'),
    ('날씨가 맑아서 우리는 산책을 오래 즐겼다', None, None),
]

KEY = {'참': 'f', '거짓': 'j'}
MAXW = 8  # w1..w8 (필러는 6~8어절)

BASE_COLS = ['list', 'itemID', 'cond', 'EU', 'trialType', 'sentence'] + \
            ['w%d' % i for i in range(1, MAXW + 1)] + \
            ['nRegion', 'critRegion', 'precritRegion', 'critWord',
             'qFlag', 'question', 'corrAns', 'corrKey']
TRIG_COLS = ['trigStart'] + ['trig%d' % i for i in range(1, MAXW + 1)] + ['trigQ']


def make_row(list_no, item_id, cond, sentence, q, ans, trial_type, trig_base=None):
    words = sentence.split(' ')
    assert 1 <= len(words) <= MAXW, sentence
    row = {
        'list': list_no, 'itemID': item_id, 'cond': cond, 'EU': '',
        'trialType': trial_type, 'sentence': sentence,
        'nRegion': len(words), 'critRegion': '', 'precritRegion': '', 'critWord': '',
        'qFlag': 1 if q else 0, 'question': q or '', 'corrAns': ans or '',
        'corrKey': KEY[ans] if ans else '',
    }
    for i in range(MAXW):
        row['w%d' % (i + 1)] = words[i] if i < len(words) else ''
    if trig_base is not None:
        row['trigStart'] = trig_base
        for i in range(MAXW):
            row['trig%d' % (i + 1)] = trig_base + i + 1 if i < len(words) else ''
        row['trigQ'] = 200
    return row


def target_rows(exp_no, sheet):
    wb = openpyxl.load_workbook(os.path.join(STIM, 'exp%d_targets.xlsx' % exp_no), data_only=True)
    ws = wb[sheet]
    rows = list(ws.iter_rows(values_only=True))
    header = list(rows[0])
    out = []
    for r in rows[1:]:
        d = dict(zip(header, r))
        if d.get('itemID') is None:
            continue
        for k, v in list(d.items()):
            if v is None:
                d[k] = ''
        d['w8'] = ''
        if exp_no == 3:
            d['trig8'] = ''
        out.append(d)
    return out


def write_xlsx(path, cols, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'trials'
    ws.append(cols)
    for r in rows:
        ws.append([r.get(c, '') for c in cols])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wb.save(path)
    print('wrote', os.path.relpath(path, ROOT), len(rows), 'rows')


def main():
    # 필러·연습 원본 (트리거 열 포함 — SPR 실험에서는 무시된다)
    fill = [make_row(0, 100 + i, 'F', s, q, a, 'filler', 90)
            for i, (s, q, a) in enumerate(FILLERS, 1)]
    prac = [make_row(0, 900 + i, 'P', s, q, a, 'practice', 80)
            for i, (s, q, a) in enumerate(PRACTICE, 1)]
    nq = sum(r['qFlag'] for r in fill)
    print('fillers: %d (questions %d = %.0f%%)' % (len(fill), nq, 100.0 * nq / len(fill)))
    write_xlsx(os.path.join(STIM, 'fillers.xlsx'), BASE_COLS + TRIG_COLS, fill)
    write_xlsx(os.path.join(STIM, 'practice.xlsx'), BASE_COLS + TRIG_COLS, prac)

    for exp_no, folder in EXP_DIRS.items():
        cols = BASE_COLS + (TRIG_COLS if exp_no == 3 else [])
        cdir = os.path.join(ROOT, folder, 'conditions')
        n_lists = 2 if exp_no == 1 else 3
        for k in range(1, n_lists + 1):
            targets = target_rows(exp_no, 'list%d' % k)
            rows = targets + [dict(r, list=k) for r in fill]
            write_xlsx(os.path.join(cdir, 'exp%d_list%d.xlsx' % (exp_no, k)), cols, rows)
        write_xlsx(os.path.join(cdir, 'practice.xlsx'), cols, prac)


if __name__ == '__main__':
    main()
